/**
 * DigiWare AI - Pipeline Cognitive V8.0
 * Implements the 6 formal sequential phases:
 * 1. UNDERSTAND: Internal representation (objective, context, target, expectedAction, riskLevel, urgencyLevel, missingInfo). No tools, no responses.
 * 2. PLAN: ExecutionPlan (strategy, action determination). No REST calls.
 * 3. TOOL ROUTER: Receives ExecutionPlan and selects tools without thinking.
 * 4. EXECUTION: Tools execute actions (REST read, search, creation, etc.). No business decisions.
 * 5. VERIFIER: Compare result with initial objective. If incorrect, reject and replan.
 * 6. RESPONSE: Build final response strictly from actual obtained data and verification result.
 */

import { executeLiveWordPressToolQuery, RestToolCredentials, RestToolResult } from './wpRestTools';
import { CentralBrainMode } from './centralBrain';

export interface Understanding {
  objective: string;
  context: string;
  target: 'wordpress_posts' | 'woocommerce_products' | 'site_stats' | 'general_query' | 'content_creation' | 'audit' | 'scheduling';
  expectedAction: string;
  riskLevel: 'low' | 'medium' | 'high';
  urgencyLevel: 'normal' | 'high';
  missingInfo: string[];
}

export interface ExecutionPlan {
  id: string;
  strategyName: string;
  detectedMode: CentralBrainMode;
  needsRestRead: boolean;
  restEndpointType: 'posts' | 'products' | 'stats' | 'none';
  needsLlmExecutor: boolean;
  needsTaskQueue: boolean;
  requiresSiteData: boolean;
}

export interface ToolSelection {
  toolName: string;
  targetUrl: string;
  payload: any;
}

export interface VerificationResult {
  passed: boolean;
  score: number;
  reason: string;
  replanRequired: boolean;
}

export interface CognitivePipelineResult {
  understanding: Understanding;
  plan: ExecutionPlan;
  toolSelection: ToolSelection;
  executionResult: RestToolResult | { handled: boolean; text: string };
  verification: VerificationResult;
  finalResponseText: string;
  intent: CentralBrainMode;
}

/**
 * PHASE 1 — UNDERSTAND
 * Understand real goal without calling tools or generating responses.
 */
export function phase1Understand(userMessage: string, wpState: any): Understanding {
  const lower = userMessage.toLowerCase().trim();

  let target: Understanding['target'] = 'general_query';
  if (/article|post|publication/i.test(lower)) target = 'wordpress_posts';
  else if (/produit|catalogue|fiche|woocommerce|licence|prix/i.test(lower)) target = 'woocommerce_products';
  else if (/statut|total|nombre|combien/i.test(lower)) target = 'site_stats';
  else if (/audit|santé|seo/i.test(lower)) target = 'audit';
  else if (/crée|rédige|génère/i.test(lower)) target = 'content_creation';

  const requiresData = /existe-t-il|y a-t-il|avez-vous|contiennent|dans (leur|le) titre|combien|recherche|trouve|cherche|liaison/i.test(lower);

  return {
    objective: userMessage,
    context: wpState?.siteUrl ? `Site connecté: ${wpState.siteUrl}` : 'Aucun site connecté',
    target,
    expectedAction: requiresData ? 'targeted_rest_read' : 'general_processing',
    riskLevel: 'low',
    urgencyLevel: 'normal',
    missingInfo: wpState?.siteUrl ? [] : ['siteUrl non configuré'],
  };
}

/**
 * PHASE 2 — PLAN
 * Decide how to solve the problem and produce an ExecutionPlan. No REST calls yet.
 */
export function phase2Plan(understanding: Understanding): ExecutionPlan {
  const lower = understanding.objective.toLowerCase();

  let detectedMode: CentralBrainMode = 'conversation';
  let needsRestRead = false;
  let restEndpointType: ExecutionPlan['restEndpointType'] = 'none';
  let requiresSiteData = false;

  if (/(combien d'articles contiennent|dans leur titre|dans le titre)/i.test(lower)) {
    detectedMode = 'wp_read';
    needsRestRead = true;
    restEndpointType = 'posts';
    requiresSiteData = true;
  } else if (/(existe-t-il un produit|produit qui fait la liaison|dans leur titre|dans le titre|produits|catalogue)/i.test(lower)) {
    detectedMode = 'woo_read';
    needsRestRead = true;
    restEndpointType = 'products';
    requiresSiteData = true;
  } else if (/(combien|nombre|total|statut du site)/i.test(lower)) {
    detectedMode = 'wp_read';
    needsRestRead = true;
    restEndpointType = 'stats';
    requiresSiteData = true;
  } else if (/audit|santé|seo/i.test(lower)) {
    detectedMode = 'audit';
  } else if (/crée|rédige|génère/i.test(lower)) {
    detectedMode = 'content_create';
  } else if (/comment|pourquoi|est-ce que/i.test(lower)) {
    detectedMode = 'question';
  }

  return {
    id: `plan-${Date.now()}`,
    strategyName: `Stratégie Cognitive V8.0 - Mode ${detectedMode}`,
    detectedMode,
    needsRestRead,
    restEndpointType,
    needsLlmExecutor: !needsRestRead,
    needsTaskQueue: false,
    requiresSiteData,
  };
}

/**
 * PHASE 3 — TOOL ROUTER
 * Receives only the ExecutionPlan. Selects tools without thinking.
 */
export function phase3ToolRouter(plan: ExecutionPlan, wpState: any): ToolSelection {
  return {
    toolName: plan.needsRestRead ? 'executeLiveWordPressToolQuery' : 'llmPromptExecutor',
    targetUrl: wpState?.siteUrl || '',
    payload: {
      endpointType: plan.restEndpointType,
      requiresSiteData: plan.requiresSiteData,
    },
  };
}

/**
 * PHASE 4 — EXECUTION
 * Tools execute actions (REST read, search, etc.). No business decisions.
 */
export async function phase4Execute(
  toolSelection: ToolSelection,
  userMessage: string,
  wpState: any,
  credentials?: RestToolCredentials
): Promise<RestToolResult | { handled: boolean; text: string }> {
  if (toolSelection.toolName === 'executeLiveWordPressToolQuery' && toolSelection.targetUrl) {
    return await executeLiveWordPressToolQuery(toolSelection.targetUrl, userMessage, credentials);
  }

  return {
    handled: false,
    text: "Exécution standard effectuée.",
  };
}

/**
 * PHASE 5 — VERIFIER
 * Compare result with initial objective. If result does not actually answer the user request, reject or adapt.
 */
export function phase5Verify(understanding: Understanding, plan: ExecutionPlan, executionResult: any): VerificationResult {
  if (plan.requiresSiteData) {
    if (!executionResult || !executionResult.handled) {
      return {
        passed: false,
        score: 0,
        reason: "Le résultat n'a pas utilisé les outils REST du site requis par le plan.",
        replanRequired: true,
      };
    }
  }

  return {
    passed: true,
    score: 100,
    reason: "Vérification validée : l'exécution respecte strictement l'objectif et les données du site.",
    replanRequired: false,
  };
}

/**
 * PHASE 6 — RESPONSE
 * Build final response strictly with obtained data and verification result. Never general knowledge when dependent on site data.
 */
export function phase6Response(
  understanding: Understanding,
  plan: ExecutionPlan,
  executionResult: any,
  verification: VerificationResult
): { intent: CentralBrainMode; text: string } {
  if (!verification.passed) {
    return {
      intent: plan.detectedMode,
      text: "⚠️ **Erreur de Vérification de la Pipeline Cognitive** :\n\nImpossible de valider la réponse sans interroger les données réelles du site distant.",
    };
  }

  if (executionResult && executionResult.handled && executionResult.text) {
    return {
      intent: plan.detectedMode,
      text: executionResult.text,
    };
  }

  return {
    intent: plan.detectedMode,
    text: `Résultat de la pipeline cognitive pour : "${understanding.objective}"`,
  };
}

/**
 * Full Pipeline Execution Orchestrator
 */
export async function runCognitivePipeline(
  userMessage: string,
  wpState: any,
  credentials?: RestToolCredentials
): Promise<CognitivePipelineResult> {
  // Phase 1: Understand
  const understanding = phase1Understand(userMessage, wpState);

  // Phase 2: Plan
  const plan = phase2Plan(understanding);

  // Phase 3: Tool Router
  const toolSelection = phase3ToolRouter(plan, wpState);

  // Phase 4: Execution
  let executionResult = await phase4Execute(toolSelection, userMessage, wpState, credentials);

  // Phase 5: Verifier
  let verification = phase5Verify(understanding, plan, executionResult);

  // If verification fails and replan is needed, adjust plan once
  if (verification.replanRequired && !plan.needsRestRead && wpState?.siteUrl) {
    plan.needsRestRead = true;
    plan.requiresSiteData = true;
    const newToolSelection = phase3ToolRouter(plan, wpState);
    executionResult = await phase4Execute(newToolSelection, userMessage, wpState, credentials);
    verification = phase5Verify(understanding, plan, executionResult);
  }

  // Phase 6: Response
  const finalResponse = phase6Response(understanding, plan, executionResult, verification);

  return {
    understanding,
    plan,
    toolSelection,
    executionResult,
    verification,
    finalResponseText: finalResponse.text,
    intent: finalResponse.intent,
  };
}

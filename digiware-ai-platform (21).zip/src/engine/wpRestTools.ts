/**
 * Live WordPress / WooCommerce REST API Tool Orchestrator V6.3
 * Performs Statistical Reads (Type 1) and Targeted Search/Filter Reads (Type 2).
 */

export interface RestToolCredentials {
  username?: string;
  appPassword?: string;
}

export interface RestToolResult {
  handled: boolean;
  text: string;
  postsCount?: number;
  productsCount?: number;
  matchCount?: number;
  readType?: 'statistical' | 'targeted';
  items?: any[];
}

/**
 * Extracts key search terms from a natural language user prompt.
 */
export function extractSearchTerms(userMessage: string): string[] {
  const stopwords = new Set([
    'combien', 'd\'articles', 'd\'article', 'de', 'du', 'des', 'le', 'la', 'les', 'un', 'une',
    'mon', 'ma', 'mes', 'ton', 'ta', 'tes', 'son', 'sa', 'ses', 'notre', 'nos', 'votre', 'vos',
    'leur', 'leurs', 'dans', 'sur', 'avec', 'sans', 'pour', 'par', 'qui', 'que', 'quoi', 'dont',
    'où', 'et', 'ou', 'ni', 'car', 'est', 'sont', 'a', 'ont', 'fait', 'font', 'existe-t-il', 'existe',
    't-il', 'y', 'a-t-il', 'est-ce', 'qu\'il', 'avez-vous', 'trouve', 'cherche', 'recherche',
    'produit', 'produits', 'article', 'articles', 'titre', 'titres', 'nom', 'noms', 'page', 'pages',
    'liaison', 'entre', 'contiennent', 'contient', 'comprend', 'comprennent', 'catalogue', 'site',
    'wordpress', 'woocommerce', 'nombre', 'total', 'totaux', 'liste', 'voir', 'affiche'
  ]);

  const clean = userMessage
    .toLowerCase()
    .replace(/[?,!;:.="'\(\)]/g, ' ')
    .trim();

  const words = clean.split(/\s+/).filter(w => w.length >= 2 && !stopwords.has(w));
  return Array.from(new Set(words));
}

/**
 * Main Entry Point for Live REST Tool Query Execution
 */
export async function executeLiveWordPressToolQuery(
  siteUrl: string,
  userMessage: string,
  credentials?: RestToolCredentials
): Promise<RestToolResult> {
  if (!siteUrl) {
    return {
      handled: true,
      text: "⚠️ **Aucune URL de site WordPress n'est configurée.**\n\nVeuillez vous rendre dans **WordPress & WooCommerce** > **Paramètres** pour enregistrer l'URL de votre site.",
    };
  }

  let cleanUrl = siteUrl.trim().replace(/\/+$/, "");
  if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
    cleanUrl = "https://" + cleanUrl;
  }

  const lower = userMessage.toLowerCase().trim();

  const authHeader: Record<string, string> = {};
  if (credentials?.username && credentials?.appPassword && credentials.appPassword !== "••••••••••••••••") {
    const token = Buffer.from(`${credentials.username.trim()}:${credentials.appPassword.trim().replace(/\s+/g, '')}`).toString('base64');
    authHeader['Authorization'] = `Basic ${token}`;
  }

  const defaultHeaders = {
    "User-Agent": "DigiWare-AI-Orchestrator/1.0",
    "Accept": "application/json",
    ...authHeader,
  };

  const callEndpoint = async (path: string) => {
    const url = `${cleanUrl}${path}`;
    try {
      const res = await fetch(url, { headers: defaultHeaders, signal: AbortSignal.timeout(7000) });
      const totalHeader = res.headers.get("x-wp-total");
      const total = totalHeader !== null ? parseInt(totalHeader, 10) : null;
      let data = null;
      if (res.ok) {
        try { data = await res.json(); } catch (e) {}
      }
      return { ok: res.ok, status: res.status, statusText: res.statusText, total, data, url };
    } catch (err: any) {
      return { ok: false, status: 0, statusText: err.message || "Erreur Réseau", total: null, data: null, url };
    }
  };

  // 1. Detect if request is explicitly Statistical Totals (Type 1)
  const isExplicitStats =
    (lower.includes("au total") ||
      lower.includes("possède mon site") ||
      lower.includes("statut du site") ||
      lower.includes("état du site") ||
      lower.includes("totaux du site") ||
      lower.includes("nombre total")) &&
    !lower.includes("contiennent") &&
    !lower.includes("dans le titre") &&
    !lower.includes("dans leur titre") &&
    !lower.includes("liaison") &&
    !lower.includes("avec");

  const searchTerms = extractSearchTerms(userMessage);

  const isTargetedSearch =
    searchTerms.length > 0 ||
    lower.includes("contiennent") ||
    lower.includes("dans leur titre") ||
    lower.includes("dans le titre") ||
    lower.includes("liaison entre") ||
    lower.includes("existe-t-il") ||
    lower.includes("y a-t-il") ||
    lower.includes("avez-vous") ||
    lower.includes("prix de") ||
    lower.includes("coûte");

  const isTitleTargeted =
    lower.includes("dans leur titre") ||
    lower.includes("dans le titre") ||
    lower.includes("dans les titres") ||
    lower.includes("dans le nom");

  let contentType: 'posts' | 'products' | 'categories' | 'media' | 'all' = 'all';
  if (/article|post|blog|actu/i.test(lower)) {
    contentType = 'posts';
  } else if (/produit|fiche|woocommerce|boutique|prix|stock|licence/i.test(lower)) {
    contentType = 'products';
  } else if (/catégorie|category/i.test(lower)) {
    contentType = 'categories';
  } else if (/média|image|photo/i.test(lower)) {
    contentType = 'media';
  }

  // --- TYPE 2: TARGETED SEARCH READ ---
  if (isTargetedSearch && !isExplicitStats) {
    // A) Search Posts
    if (contentType === 'posts') {
      const postsRes = await callEndpoint("/wp-json/wp/v2/posts?per_page=100");
      const postsData = (postsRes.ok && Array.isArray(postsRes.data)) ? postsRes.data : [];

      const matches = postsData.filter((item: any) => {
        const title = (item.title?.rendered || item.name || "").toLowerCase();
        const content = (item.excerpt?.rendered || item.content?.rendered || "").toLowerCase();

        if (isTitleTargeted) {
          return searchTerms.every(term => title.includes(term.toLowerCase()));
        } else {
          return searchTerms.every(term => title.includes(term.toLowerCase()) || content.includes(term.toLowerCase()));
        }
      });

      if (matches.length > 0) {
        const listLines = matches.map((m: any, idx: number) => {
          const title = m.title?.rendered || "Sans titre";
          const link = m.link ? ` ([Lien Direct](${m.link}))` : "";
          return `${idx + 1}. **${title}**${link}`;
        }).join("\n");

        return {
          handled: true,
          readType: 'targeted',
          matchCount: matches.length,
          text: `🎯 **Résultat de la Recherche Ciblée REST API sur votre site (\`${cleanUrl}\`)** :\n\n* **Articles trouvés** : **${matches.length}** article(s) correspondant à **"${searchTerms.join('", "')}"** ${isTitleTargeted ? 'dans leur titre' : ''}.\n\n${listLines}\n\n\`Source REST API : /wp-json/wp/v2/posts\``
        };
      } else {
        return {
          handled: true,
          readType: 'targeted',
          matchCount: 0,
          text: `🎯 **Résultat de la Recherche Ciblée REST API sur votre site (\`${cleanUrl}\`)** :\n\n❌ **0 article trouvé.**\n\n* **Termes recherchés** : **"${searchTerms.join('", "')}"** ${isTitleTargeted ? '(filtré spécifiquement sur le titre des articles)' : ''}\n* **Vérification REST API** : Scan complet effectué en direct sur vos articles WordPress. Aucun article ne possède ces termes dans son titre.\n\n*L'assistant DigiWare AI s'appuie exclusivement sur la base de données réelle de votre site distant. Aucune donnée externe ou hypothétique n'est inventée.*`
        };
      }
    }

    // B) Search Products or Catalog
    if (contentType === 'products' || contentType === 'all') {
      let wooRes = await callEndpoint("/wp-json/wc/v3/products?per_page=100");
      if (!wooRes.ok) {
        wooRes = await callEndpoint("/wp-json/wp/v2/product?per_page=100");
      }

      const productsData = (wooRes.ok && Array.isArray(wooRes.data)) ? wooRes.data : [];

      const matches = productsData.filter((item: any) => {
        const title = (item.name || item.title?.rendered || "").toLowerCase();
        const content = (item.description || item.short_description || item.excerpt?.rendered || "").toLowerCase();

        if (isTitleTargeted) {
          return searchTerms.every(term => title.includes(term.toLowerCase()));
        } else {
          return searchTerms.every(term => title.includes(term.toLowerCase()) || content.includes(term.toLowerCase()));
        }
      });

      if (matches.length > 0) {
        const listLines = matches.map((m: any, idx: number) => {
          const title = m.name || m.title?.rendered || "Sans titre";
          const price = m.price ? ` - **${m.price} €**` : "";
          const status = m.status ? ` [${m.status}]` : "";
          const link = m.permalink || m.link ? ` ([Lien Direct](${m.permalink || m.link}))` : "";
          return `${idx + 1}. **${title}**${price}${status}${link}`;
        }).join("\n");

        return {
          handled: true,
          readType: 'targeted',
          matchCount: matches.length,
          text: `🎯 **Résultat de la Recherche Ciblée REST API sur votre site (\`${cleanUrl}\`)** :\n\n* **Produits trouvés** : **${matches.length}** produit(s) correspondant à **"${searchTerms.join('", "')}"** ${isTitleTargeted ? 'dans leur titre' : ''}.\n\n${listLines}\n\n\`Source REST API : ${wooRes.url}\``
        };
      } else {
        return {
          handled: true,
          readType: 'targeted',
          matchCount: 0,
          text: `🎯 **Résultat de la Recherche Ciblée REST API sur votre site (\`${cleanUrl}\`)** :\n\n❌ **Aucun produit correspondant n'a été trouvé dans votre catalogue.**\n\n* **Termes recherchés** : **"${searchTerms.join('", "')}"** ${isTitleTargeted ? '(filtré sur les titres)' : ''}\n* **Vérification REST API** : Scan en direct de votre catalogue WooCommerce (${wooRes.total ?? productsData.length} produits vérifiés au total).\n\n*L'assistant DigiWare AI certifie qu'aucun produit du catalogue ne correspond à cette requête. Aucune fiche ou produit externe n'a été inventé.*`
        };
      }
    }
  }

  // --- TYPE 1: STATISTICAL READ / METRICS ---
  if (
    isExplicitStats ||
    lower.includes("combien") ||
    lower.includes("total") ||
    lower.includes("nombre") ||
    lower.includes("statut du site") ||
    lower.includes("état du site")
  ) {
    const postsRes = await callEndpoint("/wp-json/wp/v2/posts?per_page=1");
    const pagesRes = await callEndpoint("/wp-json/wp/v2/pages?per_page=1");
    let wooRes = await callEndpoint("/wp-json/wc/v3/products?per_page=1");
    if (!wooRes.ok) {
      wooRes = await callEndpoint("/wp-json/wp/v2/product?per_page=1");
    }
    const categoriesRes = await callEndpoint("/wp-json/wp/v2/categories?per_page=1");

    const postsCount = postsRes.total ?? (Array.isArray(postsRes.data) ? postsRes.data.length : 0);
    const pagesCount = pagesRes.total ?? (Array.isArray(pagesRes.data) ? pagesRes.data.length : 0);
    const productsCount = wooRes.total ?? (Array.isArray(wooRes.data) ? wooRes.data.length : 0);
    const categoriesCount = categoriesRes.total ?? (Array.isArray(categoriesRes.data) ? categoriesRes.data.length : 0);

    let siteDetails = `📊 **Données Statutaires Réelles Lues en Direct via REST API sur \`${cleanUrl}\`**\n\n`;
    siteDetails += `* **Articles WordPress** : **${postsCount}** \`(Endpoint: GET /wp-json/wp/v2/posts - Statut ${postsRes.status})\`\n`;
    siteDetails += `* **Produits WooCommerce** : **${productsCount}** \`(Endpoint: GET /wp-json/wc/v3/products - Statut ${wooRes.status})\`\n`;
    siteDetails += `* **Pages WordPress** : **${pagesCount}** \`(Endpoint: GET /wp-json/wp/v2/pages - Statut ${pagesRes.status})\`\n`;
    siteDetails += `* **Catégories** : **${categoriesCount}** \`(Endpoint: GET /wp-json/wp/v2/categories - Statut ${categoriesRes.status})\`\n\n`;
    siteDetails += `✅ *Orchestration vérifiée : les totaux ci-dessus sont extraits directement des en-têtes \`X-WP-Total\` renvoyés par votre serveur distant.*`;

    return { handled: true, readType: 'statistical', text: siteDetails, postsCount, productsCount };
  }

  // --- CATEGORIES / MEDIA / TAGS READ ---
  if (lower.includes("catégorie") || lower.includes("média") || lower.includes("image") || lower.includes("tag")) {
    let ep = "/wp-json/wp/v2/categories?per_page=20";
    if (lower.includes("tag")) ep = "/wp-json/wp/v2/tags?per_page=20";
    if (lower.includes("média") || lower.includes("image")) ep = "/wp-json/wp/v2/media?per_page=20";

    const catRes = await callEndpoint(ep);
    if (catRes.ok && Array.isArray(catRes.data) && catRes.data.length > 0) {
      const names = catRes.data.map((c: any) => `- **${c.name || c.title?.rendered || 'Élément'}** (${c.count ?? 0} éléments associés)`).join("\n");
      return {
        handled: true,
        readType: 'targeted',
        text: `📁 **Données Lues Réellement en Direct sur WordPress** :\n\n${names}\n\n\`Source: ${catRes.url}\``
      };
    } else {
      return {
        handled: true,
        readType: 'targeted',
        text: `Cette fonctionnalité n'est pas encore accessible directement sur le site connecté (Statut HTTP ${catRes.status}).`
      };
    }
  }

  return { handled: false, text: "" };
}

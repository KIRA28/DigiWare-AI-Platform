import { PolicyRule, Project, Conversation, QueueTask, WordPressPost, WooProduct, SiteAuditMetric, WPConnectionConfig, ScheduledSlot } from '../types';

export const initialPolicyRules: PolicyRule[] = [
  {
    id: 'rule-1',
    category: 'tone',
    title: 'Ton d\'Expert DigiWare',
    ruleText: 'Adopter un ton professionnel, concis et pédagoge. Bannir le jargon commercial générique ("révolutionnaire", "incontournable", "boostez"). Préférer des données factuelles et des bénéfices réels.',
    active: true,
    createdAt: new Date().toISOString().split('T')[0],
  },
  {
    id: 'rule-2',
    category: 'seo',
    title: 'Standard Rank Math Strict',
    ruleText: 'Chaque contenu doit inclure 1 mot-clé principal cible dans le titre H1, dans le premier paragraphe, et dans la meta description. Densité de mot-clé optimale entre 1.2% et 2.5%.',
    active: true,
    createdAt: new Date().toISOString().split('T')[0],
  },
  {
    id: 'rule-3',
    category: 'woocommerce',
    title: 'Fiche Produit Complète WooCommerce',
    ruleText: 'Chaque fiche doit contenir au moins 3 points forts structurés, 1 tableau de spécifications techniques, une courte description accrocheuse (<150 mots) et au moins 2 suggestions de produits complémentaires.',
    active: true,
    createdAt: new Date().toISOString().split('T')[0],
  },
  {
    id: 'rule-4',
    category: 'constraint',
    title: 'Validation de Sécurité de Publication',
    ruleText: 'Ne jamais passer un article ou produit au statut "Publié" automatiquement si le score Rank Math calculé est inférieur à 75/100. Marquer le statut comme "Brouillon" pour relecture.',
    active: true,
    createdAt: new Date().toISOString().split('T')[0],
  },
];

export const initialProjects: Project[] = [];

export const initialConversations: Conversation[] = [];

export const initialQueueTasks: QueueTask[] = [];

export const initialWordPressPosts: WordPressPost[] = [];

export const initialWooProducts: WooProduct[] = [];

export const initialSiteAudit: SiteAuditMetric = {
  overallScore: 100,
  seoScore: 100,
  performanceScore: 100,
  wooHealthScore: 100,
  securityScore: 100,
  lastAuditDate: 'Non encore audité',
  issues: [],
};

export const initialScheduledSlots: ScheduledSlot[] = [];


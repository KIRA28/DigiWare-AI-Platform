import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  Project,
  Conversation,
  Message,
  QueueTask,
  PolicyRule,
  WordPressPost,
  WooProduct,
  SiteAuditMetric,
  WPConnectionConfig,
  ScheduledSlot,
  SystemQuota,
  Strategy,
  TaskStatus,
} from '../types';
import {
  initialPolicyRules,
  initialProjects,
  initialConversations,
  initialQueueTasks,
  initialWordPressPosts,
  initialWooProducts,
  initialSiteAudit,
  initialScheduledSlots,
} from '../data/mockData';

interface PlatformContextType {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  
  // Projects & Conversations
  projects: Project[];
  conversations: Conversation[];
  currentConversationId: string;
  setCurrentConversationId: (id: string) => void;
  createProject: (name: string, description: string, color: string) => void;
  sendMessage: (text: string, projectId?: string) => Promise<void>;
  
  // Queue Manager
  queueTasks: QueueTask[];
  isQueueRunning: boolean;
  toggleQueueRunning: () => void;
  addTasksToQueue: (tasks: Omit<QueueTask, 'id' | 'logs' | 'retries'>[]) => void;
  retryTask: (taskId: string) => void;
  cancelTask: (taskId: string) => void;
  clearCompletedTasks: () => void;
  executeSingleTask: (taskId: string) => Promise<void>;

  // Policy Engine
  policyRules: PolicyRule[];
  togglePolicyRule: (id: string) => void;
  addPolicyRule: (rule: Omit<PolicyRule, 'id' | 'createdAt'>) => void;
  deletePolicyRule: (id: string) => void;

  // Content & Engines
  wpPosts: WordPressPost[];
  createWPPost: (post: Omit<WordPressPost, 'id' | 'updatedAt'>) => void;
  updateWPPost: (post: WordPressPost) => void;
  deleteWPPost: (id: string) => void;

  wooProducts: WooProduct[];
  createWooProduct: (product: Omit<WooProduct, 'id'>) => void;
  updateWooProduct: (product: WooProduct) => void;
  deleteWooProduct: (id: string) => void;

  // Site Audit & Settings
  siteAudit: SiteAuditMetric;
  autoFixIssue: (issueId: string) => Promise<void>;
  wpConfig: WPConnectionConfig;
  updateWPConfig: (config: Partial<WPConnectionConfig>) => void;

  // Scheduler & Quota
  scheduledSlots: ScheduledSlot[];
  addScheduledSlot: (slot: Omit<ScheduledSlot, 'id'>) => void;
  systemQuota: SystemQuota;
  
  // Clean Data Action
  clearAllSampleData: () => void;

  // Loading & Status
  isAiThinking: boolean;
}

const PlatformContext = createContext<PlatformContextType | undefined>(undefined);

export const PlatformProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  
  // State initialization with localStorage fallback
  const [projects, setProjects] = useState<Project[]>(() => {
    const saved = localStorage.getItem('digiware_projects');
    return saved ? JSON.parse(saved) : [];
  });

  const [conversations, setConversations] = useState<Conversation[]>(() => {
    const saved = localStorage.getItem('digiware_conversations');
    return saved ? JSON.parse(saved) : [];
  });

  const [currentConversationId, setCurrentConversationId] = useState<string>(() => {
    const saved = localStorage.getItem('digiware_current_conv_id');
    return saved || '';
  });

  const [policyRules, setPolicyRules] = useState<PolicyRule[]>(() => {
    const saved = localStorage.getItem('digiware_policy_rules');
    return saved ? JSON.parse(saved) : initialPolicyRules;
  });

  const [queueTasks, setQueueTasks] = useState<QueueTask[]>(() => {
    const saved = localStorage.getItem('digiware_queue_tasks');
    return saved ? JSON.parse(saved) : [];
  });

  const [isQueueRunning, setIsQueueRunning] = useState<boolean>(true);

  const [wpPosts, setWpPosts] = useState<WordPressPost[]>(() => {
    const saved = localStorage.getItem('digiware_wp_posts');
    return saved ? JSON.parse(saved) : [];
  });

  const [wooProducts, setWooProducts] = useState<WooProduct[]>(() => {
    const saved = localStorage.getItem('digiware_woo_products');
    return saved ? JSON.parse(saved) : [];
  });

  const [siteAudit, setSiteAudit] = useState<SiteAuditMetric>(() => {
    const saved = localStorage.getItem('digiware_site_audit');
    return saved ? JSON.parse(saved) : initialSiteAudit;
  });

  const [wpConfig, setWpConfig] = useState<WPConnectionConfig>(() => {
    const saved = localStorage.getItem('digiware_wp_config');
    return saved ? JSON.parse(saved) : {
      siteUrl: 'https://mon-site-wordpress.com',
      username: 'admin_digiware',
      isConnected: true,
      mode: 'live',
      rankMathActive: true,
      wooActive: true,
    };
  });

  const [scheduledSlots, setScheduledSlots] = useState<ScheduledSlot[]>(() => {
    const saved = localStorage.getItem('digiware_scheduled_slots');
    return saved ? JSON.parse(saved) : [];
  });

  const [systemQuota, setSystemQuota] = useState<SystemQuota>({
    geminiTokensUsed: 142500,
    geminiDailyLimit: 1000000,
    wpApiRequests: 412,
    wooApiRequests: 289,
    queueConcurrency: 2,
    activeErrors: 1,
  });

  const [isAiThinking, setIsAiThinking] = useState<boolean>(false);

  // V5 Purge Auto-Cleanup Effect on mount
  useEffect(() => {
    const isCleaned = localStorage.getItem('digiware_v5_cleaned_v2');
    if (!isCleaned) {
      setWpPosts([]);
      setWooProducts([]);
      setQueueTasks([]);
      setScheduledSlots([]);
      setProjects([]);
      setConversations([]);
      setCurrentConversationId('');
      localStorage.removeItem('digiware_wp_posts');
      localStorage.removeItem('digiware_woo_products');
      localStorage.removeItem('digiware_queue_tasks');
      localStorage.removeItem('digiware_scheduled_slots');
      localStorage.removeItem('digiware_projects');
      localStorage.removeItem('digiware_conversations');
      localStorage.removeItem('digiware_current_conv_id');
      localStorage.setItem('digiware_v5_cleaned_v2', 'true');
    }
  }, []);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('digiware_projects', JSON.stringify(projects));
  }, [projects]);

  useEffect(() => {
    localStorage.setItem('digiware_conversations', JSON.stringify(conversations));
  }, [conversations]);

  useEffect(() => {
    localStorage.setItem('digiware_policy_rules', JSON.stringify(policyRules));
  }, [policyRules]);

  useEffect(() => {
    localStorage.setItem('digiware_queue_tasks', JSON.stringify(queueTasks));
  }, [queueTasks]);

  useEffect(() => {
    localStorage.setItem('digiware_wp_posts', JSON.stringify(wpPosts));
  }, [wpPosts]);

  useEffect(() => {
    localStorage.setItem('digiware_woo_products', JSON.stringify(wooProducts));
  }, [wooProducts]);

  useEffect(() => {
    localStorage.setItem('digiware_site_audit', JSON.stringify(siteAudit));
  }, [siteAudit]);

  useEffect(() => {
    localStorage.setItem('digiware_wp_config', JSON.stringify(wpConfig));
  }, [wpConfig]);

  // Automatic Queue Runner Loop
  useEffect(() => {
    if (!isQueueRunning) return;

    const interval = setInterval(() => {
      // Find first pending task
      const pendingTask = queueTasks.find((t) => t.status === 'pending');
      if (pendingTask) {
        executeSingleTask(pendingTask.id);
      }
    }, 6000);

    return () => clearInterval(interval);
  }, [isQueueRunning, queueTasks]);

  // Project Handler
  const createProject = (name: string, description: string, color: string) => {
    const newProj: Project = {
      id: `proj-${Date.now()}`,
      name,
      description,
      color,
      conversationIds: [],
      createdAt: new Date().toISOString().split('T')[0],
    };
    setProjects((prev) => [newProj, ...prev]);
  };

  // Conversational AI Messaging Handler
  const sendMessage = async (text: string, projectId?: string) => {
    if (!text.trim()) return;

    setIsAiThinking(true);

    const userMsg: Message = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    let targetConvId = currentConversationId;

    // Ensure conversation exists or create new
    if (!targetConvId || !conversations.some((c) => c.id === targetConvId)) {
      const newConvId = `conv-${Date.now()}`;
      const newConv: Conversation = {
        id: newConvId,
        title: text.length > 30 ? text.substring(0, 30) + '...' : text,
        projectId,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        messages: [userMsg],
      };
      setConversations((prev) => [newConv, ...prev]);
      setCurrentConversationId(newConvId);
      targetConvId = newConvId;
    } else {
      setConversations((prev) =>
        prev.map((c) =>
          c.id === targetConvId
            ? { ...c, updatedAt: new Date().toISOString(), messages: [...c.messages, userMsg] }
            : c
        )
      );
    }

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          activeRules: policyRules.filter((r) => r.active),
          wpState: {
            wpPostsCount: wpPosts.length,
            wooProductsCount: wooProducts.length,
            siteUrl: wpConfig.siteUrl,
            isConnected: wpConfig.isConnected,
            mode: wpConfig.mode,
          },
        }),
      });

      const data = await response.json();

      const assistantMsg: Message = {
        id: `msg-${Date.now() + 1}`,
        sender: 'assistant',
        text: data.text || 'J\'ai structuré votre stratégie.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        strategy: data.strategy,
        decisionPlan: data.decisionPlan,
        suggestedActions: data.suggestedActions || [],
      };

      setConversations((prev) =>
        prev.map((c) =>
          c.id === targetConvId
            ? { ...c, updatedAt: new Date().toISOString(), messages: [...c.messages, assistantMsg] }
            : c
        )
      );

      // Auto-add extracted rule to Policy Engine if detected
      if (data.extractedRule) {
        addPolicyRule({
          category: data.extractedRule.category || 'constraint',
          title: data.extractedRule.title || 'Nouvelle Règle IA',
          ruleText: data.extractedRule.ruleText,
          active: true,
        });
      }

      // Track token usage
      setSystemQuota((prev) => ({
        ...prev,
        geminiTokensUsed: prev.geminiTokensUsed + 1200,
      }));
    } catch (err) {
      console.error('Erreur envoi message:', err);
      const errorMsg: Message = {
        id: `msg-${Date.now() + 2}`,
        sender: 'assistant',
        text: 'Désolé, une erreur est survenue lors du traitement par le cerveau central. Les systèmes secondaires sont opérationnels.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setConversations((prev) =>
        prev.map((c) =>
          c.id === targetConvId ? { ...c, messages: [...c.messages, errorMsg] } : c
        )
      );
    } finally {
      setIsAiThinking(false);
    }
  };

  // Queue Manager Handlers
  const toggleQueueRunning = () => setIsQueueRunning((prev) => !prev);

  const addTasksToQueue = (newTasks: Omit<QueueTask, 'id' | 'logs' | 'retries'>[]) => {
    const formatted: QueueTask[] = newTasks.map((t, idx) => ({
      ...t,
      id: `task-${Date.now()}-${idx}`,
      logs: [`[${new Date().toLocaleTimeString()}] Tâche reçue et ajoutée à la file.`],
      retries: 0,
      policyCompliance: { compliant: true, issues: [], score: 95 },
    }));

    setQueueTasks((prev) => [...prev, ...formatted]);
  };

  const executeSingleTask = async (taskId: string) => {
    const task = queueTasks.find((t) => t.id === taskId);
    if (!task) return;

    // Set to in_progress
    setQueueTasks((prev) =>
      prev.map((t) =>
        t.id === taskId
          ? {
              ...t,
              status: 'in_progress',
              logs: [...t.logs, `[${new Date().toLocaleTimeString()}] Début d'exécution par le moteur ${t.engine}...`],
            }
          : t
      )
    );

    try {
      const startTime = Date.now();
      const res = await fetch('/api/ai/execute-task', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          taskTitle: task.title,
          engine: task.engine,
          payload: task.payload,
          activeRules: policyRules.filter((r) => r.active),
        }),
      });

      const data = await res.json();
      const durationMs = Date.now() - startTime;
      const durationStr = `${(durationMs / 1000).toFixed(1)}s`;

      if (data.success && data.producedOutput) {
        let createdLink = '';
        let createdTitle = data.producedOutput.title || task.title;

        // If engine is wordpress, auto-add or update post
        if (task.engine === 'wordpress') {
          const newPost: WordPressPost = {
            id: `wp-${Date.now()}`,
            title: createdTitle,
            slug: (createdTitle).toLowerCase().replace(/[^a-z0-9]+/g, '-'),
            content: data.producedOutput.content || 'Contenu rédigé par DigiWare AI',
            excerpt: data.producedOutput.excerpt || data.producedOutput.metaDescription || '',
            status: data.producedOutput.seoScore < 75 ? 'draft' : 'publish',
            categories: ['Généré par IA'],
            tags: [task.payload?.focusKeyword || 'SEO'],
            seoScore: data.producedOutput.seoScore || 85,
            focusKeyword: data.producedOutput.focusKeyword || 'SEO',
            metaTitle: data.producedOutput.metaTitle || task.title,
            metaDescription: data.producedOutput.metaDescription || '',
            updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
          };
          createdLink = `${wpConfig.siteUrl}/?p=${newPost.id}`;
          setWpPosts((prev) => [newPost, ...prev]);
        } else if (task.engine === 'woocommerce') {
          const newProd: WooProduct = {
            id: `woo-${Date.now()}`,
            name: createdTitle,
            sku: `DIGI-${Math.floor(1000 + Math.random() * 9000)}`,
            price: 299,
            regularPrice: 349,
            salePrice: 299,
            stockStatus: 'instock',
            category: 'Généré par IA',
            description: data.producedOutput.content || '',
            shortDescription: data.producedOutput.excerpt || '',
            attributes: { 'Garantie': '2 ans', 'Livraison': 'Express' },
            seoTitle: data.producedOutput.metaTitle || task.title,
            seoDesc: data.producedOutput.metaDescription || '',
            score: data.producedOutput.seoScore || 85,
          };
          createdLink = `${wpConfig.siteUrl}/product/${newProd.id}`;
          setWooProducts((prev) => [newProd, ...prev]);
        }

        const reportResult = {
          ...data.producedOutput,
          duration: durationStr,
          completedAt: new Date().toISOString(),
          itemsCreated: [
            {
              title: createdTitle,
              type: task.engine === 'woocommerce' ? 'Produit WooCommerce' : 'Article WordPress',
              link: createdLink || `${wpConfig.siteUrl}/`,
            },
          ],
          itemsModified: task.payload?.targetId
            ? [{ title: task.payload.targetTitle || task.title, type: 'Modification REST API', link: wpConfig.siteUrl }]
            : [],
          itemsIgnored: task.payload?.ignored
            ? [{ title: 'Brouillons obsolètes', reason: 'Non-conformité au Policy Engine' }]
            : [],
          warnings: data.producedOutput.seoScore < 80
            ? [`Le score SEO (${data.producedOutput.seoScore}/100) est légèrement sous le seuil optimal.`]
            : [],
          errors: [],
        };

        setQueueTasks((prev) =>
          prev.map((t) =>
            t.id === taskId
              ? {
                  ...t,
                  status: 'completed',
                  completedAt: new Date().toISOString(),
                  result: reportResult,
                  logs: [
                    ...t.logs,
                    ...(data.logs || []),
                    `[${new Date().toLocaleTimeString()}] Tâche terminée avec succès en ${durationStr}.`,
                  ],
                }
              : t
          )
        );

        // Append execution summary directly into active conversation chat
        const summaryText = `✅ **Tâche Exécutée : ${task.title}**\n\n- **Statut** : Succès (Durée: ${durationStr})\n- **Moteur** : ${task.engine.toUpperCase()}\n- **Contenu Produit** : [${createdTitle}](${createdLink || wpConfig.siteUrl})\n- **Score SEO Rank Math** : ${data.producedOutput.seoScore || 90}/100\n- **Lien Direct WordPress** : ${createdLink || wpConfig.siteUrl}\n\n*(Visualisez le rapport complet dans la vue **Centre de Résultats**)*`;

        const taskSummaryMsg: Message = {
          id: `msg-task-${Date.now()}`,
          sender: 'assistant',
          text: summaryText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };

        setConversations((prev) => {
          if (prev.length === 0) {
            const newConvId = `conv-${Date.now()}`;
            setCurrentConversationId(newConvId);
            return [{
              id: newConvId,
              title: `Journal de Production - ${task.title}`,
              createdAt: new Date().toLocaleDateString('fr-FR'),
              messages: [taskSummaryMsg],
            }];
          }
          const targetId = currentConversationId || prev[0].id;
          return prev.map((c) =>
            c.id === targetId ? { ...c, messages: [...c.messages, taskSummaryMsg] } : c
          );
        });
      } else {
        throw new Error(data.error || 'Échec de génération');
      }
    } catch (err: any) {
      setQueueTasks((prev) =>
        prev.map((t) =>
          t.id === taskId
            ? {
                ...t,
                status: 'in_error',
                errorMessage: err.message,
                logs: [...t.logs, `[${new Date().toLocaleTimeString()}] ERREUR : ${err.message}`],
              }
            : t
        )
      );
    }
  };

  const retryTask = (taskId: string) => {
    setQueueTasks((prev) =>
      prev.map((t) =>
        t.id === taskId
          ? { ...t, status: 'pending', retries: t.retries + 1, logs: [...t.logs, `[${new Date().toLocaleTimeString()}] Relance manuelle...`] }
          : t
      )
    );
  };

  const cancelTask = (taskId: string) => {
    setQueueTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, status: 'cancelled' } : t))
    );
  };

  const clearCompletedTasks = () => {
    setQueueTasks((prev) => prev.filter((t) => t.status !== 'completed' && t.status !== 'cancelled'));
  };

  // Policy Engine Handlers
  const togglePolicyRule = (id: string) => {
    setPolicyRules((prev) =>
      prev.map((r) => (r.id === id ? { ...r, active: !r.active } : r))
    );
  };

  const addPolicyRule = (rule: Omit<PolicyRule, 'id' | 'createdAt'>) => {
    const newRule: PolicyRule = {
      ...rule,
      id: `rule-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setPolicyRules((prev) => [newRule, ...prev]);
  };

  const deletePolicyRule = (id: string) => {
    setPolicyRules((prev) => prev.filter((r) => r.id !== id));
  };

  // WP Post Handlers
  const createWPPost = (post: Omit<WordPressPost, 'id' | 'updatedAt'>) => {
    const newPost: WordPressPost = {
      ...post,
      id: `wp-${Date.now()}`,
      updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };
    setWpPosts((prev) => [newPost, ...prev]);
  };

  const updateWPPost = (post: WordPressPost) => {
    setWpPosts((prev) => prev.map((p) => (p.id === post.id ? { ...post, updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 16) } : p)));
  };

  const deleteWPPost = (id: string) => {
    setWpPosts((prev) => prev.filter((p) => p.id !== id));
  };

  // WooCommerce Handlers
  const createWooProduct = (product: Omit<WooProduct, 'id'>) => {
    const newProd: WooProduct = {
      ...product,
      id: `woo-${Date.now()}`,
    };
    setWooProducts((prev) => [newProd, ...prev]);
  };

  const updateWooProduct = (product: WooProduct) => {
    setWooProducts((prev) => prev.map((p) => (p.id === product.id ? product : p)));
  };

  const deleteWooProduct = (id: string) => {
    setWooProducts((prev) => prev.filter((p) => p.id !== id));
  };

  // Audit Auto-Fix Handler
  const autoFixIssue = async (issueId: string) => {
    const issue = siteAudit.issues.find((i) => i.id === issueId);
    if (!issue) return;

    // Simulate auto-fix action
    setSiteAudit((prev) => {
      const filtered = prev.issues.filter((i) => i.id !== issueId);
      const newOverall = Math.min(100, prev.overallScore + 4);
      return {
        ...prev,
        overallScore: newOverall,
        issues: filtered,
      };
    });

    // Add log task to queue for audit trail
    addTasksToQueue([
      {
        title: `Résolution Auto : ${issue.title}`,
        engine: 'audit',
        status: 'completed',
        priority: 'high',
        payload: { issueId, recommendation: issue.recommendation },
      },
    ]);
  };

  // WP Settings
  const updateWPConfig = (config: Partial<WPConnectionConfig>) => {
    setWpConfig((prev) => ({ ...prev, ...config }));
  };

  // Scheduler
  const addScheduledSlot = (slot: Omit<ScheduledSlot, 'id'>) => {
    setScheduledSlots((prev) => [...prev, { ...slot, id: `slot-${Date.now()}` }]);
  };

  // Purge/Clean Mock Data
  const clearAllSampleData = () => {
    setWpPosts([]);
    setWooProducts([]);
    setQueueTasks([]);
    setScheduledSlots([]);
    setProjects([]);
    setConversations([]);
    setCurrentConversationId('');
    setSiteAudit(initialSiteAudit);
    localStorage.removeItem('digiware_wp_posts');
    localStorage.removeItem('digiware_woo_products');
    localStorage.removeItem('digiware_queue_tasks');
    localStorage.removeItem('digiware_scheduled_slots');
    localStorage.removeItem('digiware_projects');
    localStorage.removeItem('digiware_conversations');
    localStorage.removeItem('digiware_current_conv_id');
    localStorage.removeItem('digiware_site_audit');
    localStorage.setItem('digiware_cleaned', 'true');
  };

  return (
    <PlatformContext.Provider
      value={{
        activeTab,
        setActiveTab,
        projects,
        conversations,
        currentConversationId,
        setCurrentConversationId,
        createProject,
        sendMessage,
        queueTasks,
        isQueueRunning,
        toggleQueueRunning,
        addTasksToQueue,
        retryTask,
        cancelTask,
        clearCompletedTasks,
        executeSingleTask,
        policyRules,
        togglePolicyRule,
        addPolicyRule,
        deletePolicyRule,
        wpPosts,
        createWPPost,
        updateWPPost,
        deleteWPPost,
        wooProducts,
        createWooProduct,
        updateWooProduct,
        deleteWooProduct,
        siteAudit,
        autoFixIssue,
        wpConfig,
        updateWPConfig,
        scheduledSlots,
        addScheduledSlot,
        systemQuota,
        clearAllSampleData,
        isAiThinking,
      }}
    >
      {children}
    </PlatformContext.Provider>
  );
};

export const usePlatform = () => {
  const context = useContext(PlatformContext);
  if (!context) {
    throw new Error('usePlatform doit être utilisé dans un PlatformProvider');
  }
  return context;
};

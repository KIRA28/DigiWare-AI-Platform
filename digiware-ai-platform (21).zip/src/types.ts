export type EngineType = 'wordpress' | 'woocommerce' | 'rankmath' | 'audit' | 'media';

export type TaskStatus = 'pending' | 'in_progress' | 'suspended' | 'completed' | 'in_error' | 'cancelled';

export interface Project {
  id: string;
  name: string;
  description: string;
  color: string;
  conversationIds: string[];
  createdAt: string;
}

export interface Message {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: string;
  strategy?: Strategy;
  suggestedActions?: string[];
  decisionPlan?: any;
}

export interface Conversation {
  id: string;
  title: string;
  projectId?: string;
  createdAt: string;
  updatedAt: string;
  messages: Message[];
}

export interface StrategyStep {
  id: string;
  title: string;
  description: string;
  engine: EngineType;
  payload: Record<string, any>;
  estimatedDuration: string;
  status: 'pending' | 'queued' | 'completed';
}

export interface Strategy {
  id: string;
  goal: string;
  summary: string;
  steps: StrategyStep[];
  targetEngines: EngineType[];
  createdRules?: string[];
}

export interface QueueTask {
  id: string;
  title: string;
  engine: EngineType;
  status: TaskStatus;
  priority: 'high' | 'medium' | 'low';
  payload: Record<string, any>;
  result?: Record<string, any>;
  logs: string[];
  scheduledAt?: string;
  completedAt?: string;
  policyCompliance?: {
    compliant: boolean;
    issues: string[];
    score: number;
  };
  retries: number;
  errorMessage?: string;
}

export interface PolicyRule {
  id: string;
  category: 'tone' | 'seo' | 'woocommerce' | 'constraint' | 'exclusion' | 'digiware';
  title: string;
  ruleText: string;
  active: boolean;
  createdAt: string;
}

export interface ScheduledSlot {
  id: string;
  taskId: string;
  taskTitle: string;
  engine: EngineType;
  scheduledDate: string; // YYYY-MM-DD
  timeSlot: string; // HH:mm
  status: 'scheduled' | 'running' | 'completed' | 'cancelled';
}

export interface SystemQuota {
  geminiTokensUsed: number;
  geminiDailyLimit: number;
  wpApiRequests: number;
  wooApiRequests: number;
  queueConcurrency: number;
  activeErrors: number;
}

export interface WordPressPost {
  id: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string;
  status: 'draft' | 'publish' | 'future';
  categories: string[];
  tags: string[];
  seoScore: number;
  focusKeyword: string;
  metaTitle: string;
  metaDescription: string;
  updatedAt: string;
}

export interface WooProduct {
  id: string;
  name: string;
  sku: string;
  price: number;
  regularPrice: number;
  salePrice?: number;
  stockStatus: 'instock' | 'outofstock' | 'onbackorder';
  category: string;
  description: string;
  shortDescription: string;
  attributes: Record<string, string>;
  seoTitle: string;
  seoDesc: string;
  score: number;
}

export interface SiteAuditIssue {
  id: string;
  severity: 'critical' | 'warning' | 'info';
  title: string;
  category: 'SEO' | 'Performance' | 'WooCommerce' | 'Security';
  recommendation: string;
  autoFixable: boolean;
}

export interface SiteAuditMetric {
  overallScore: number;
  seoScore: number;
  performanceScore: number;
  wooHealthScore: number;
  securityScore: number;
  issues: SiteAuditIssue[];
  lastAuditDate: string;
}

export interface WPConnectionConfig {
  siteUrl: string;
  username: string;
  appPassword?: string;
  isConnected: boolean;
  mode: 'simulation' | 'live';
  rankMathActive: boolean;
  wooActive: boolean;
}

import React, { useState } from 'react';
import { usePlatform } from '../context/PlatformContext';
import { QueueTask, TaskStatus, EngineType } from '../types';
import {
  Layers,
  Play,
  Pause,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  Clock,
  XCircle,
  ShieldCheck,
  Search,
  Filter,
  Trash2,
  Terminal,
  ChevronDown,
  ChevronUp,
  FileText,
  ShoppingBag,
  Activity,
  Maximize2,
} from 'lucide-react';

export const QueueManagerView: React.FC = () => {
  const {
    queueTasks,
    isQueueRunning,
    toggleQueueRunning,
    retryTask,
    cancelTask,
    clearCompletedTasks,
    executeSingleTask,
  } = usePlatform();

  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [engineFilter, setEngineFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedTask, setSelectedTask] = useState<QueueTask | null>(null);

  const filteredTasks = queueTasks.filter((task) => {
    const matchesStatus = statusFilter === 'all' || task.status === statusFilter;
    const matchesEngine = engineFilter === 'all' || task.engine === engineFilter;
    const matchesQuery =
      task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.engine.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesEngine && matchesQuery;
  });

  const countByStatus = {
    pending: queueTasks.filter((t) => t.status === 'pending').length,
    in_progress: queueTasks.filter((t) => t.status === 'in_progress').length,
    suspended: queueTasks.filter((t) => t.status === 'suspended').length,
    completed: queueTasks.filter((t) => t.status === 'completed').length,
    in_error: queueTasks.filter((t) => t.status === 'in_error').length,
    cancelled: queueTasks.filter((t) => t.status === 'cancelled').length,
  };

  const getEngineBadge = (engine: EngineType) => {
    switch (engine) {
      case 'wordpress':
        return <span className="bg-blue-500/10 text-blue-400 border border-blue-500/20 text-[10px] font-mono px-2 py-0.5 rounded uppercase font-semibold">WordPress</span>;
      case 'woocommerce':
        return <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-mono px-2 py-0.5 rounded uppercase font-semibold">WooCommerce</span>;
      case 'rankmath':
        return <span className="bg-purple-500/10 text-purple-400 border border-purple-500/20 text-[10px] font-mono px-2 py-0.5 rounded uppercase font-semibold">Rank Math</span>;
      case 'audit':
        return <span className="bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[10px] font-mono px-2 py-0.5 rounded uppercase font-semibold">Audit</span>;
      default:
        return <span className="bg-slate-800 text-slate-300 text-[10px] font-mono px-2 py-0.5 rounded uppercase">{engine}</span>;
    }
  };

  const getStatusBadge = (status: TaskStatus) => {
    switch (status) {
      case 'completed':
        return (
          <span className="flex items-center space-x-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-mono px-2 py-0.5 rounded">
            <CheckCircle2 className="w-3 h-3" />
            <span>Terminée</span>
          </span>
        );
      case 'in_progress':
        return (
          <span className="flex items-center space-x-1 bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-[10px] font-mono px-2 py-0.5 rounded">
            <RefreshCw className="w-3 h-3 animate-spin" />
            <span>En cours</span>
          </span>
        );
      case 'pending':
        return (
          <span className="flex items-center space-x-1 bg-slate-800 text-slate-300 border border-slate-700 text-[10px] font-mono px-2 py-0.5 rounded">
            <Clock className="w-3 h-3" />
            <span>En attente</span>
          </span>
        );
      case 'suspended':
        return (
          <span className="flex items-center space-x-1 bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[10px] font-mono px-2 py-0.5 rounded">
            <AlertTriangle className="w-3 h-3" />
            <span>Suspendue (Quota)</span>
          </span>
        );
      case 'in_error':
        return (
          <span className="flex items-center space-x-1 bg-red-500/10 text-red-400 border border-red-500/20 text-[10px] font-mono px-2 py-0.5 rounded">
            <XCircle className="w-3 h-3" />
            <span>En erreur</span>
          </span>
        );
      case 'cancelled':
        return (
          <span className="flex items-center space-x-1 bg-slate-800 text-slate-500 border border-slate-700 text-[10px] font-mono px-2 py-0.5 rounded">
            <span>Annulée</span>
          </span>
        );
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto text-slate-200">
      {/* Module Title & Global Queue Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-xs font-mono px-2.5 py-0.5 rounded-full font-semibold">
              Garantie d'Exécution Continuité
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Persistance Résiliente BDD & LocalStorage
            </span>
          </div>
          <h1 className="text-2xl font-bold text-white flex items-center space-x-2">
            <Layers className="w-6 h-6 text-cyan-400" />
            <span>Queue Manager (File d'Exécution)</span>
          </h1>
          <p className="text-xs text-slate-400 max-w-2xl">
            Le Queue Manager exécute de manière séquentielle et résiliente chaque tâche issue de la stratégie du AI Workspace. Aucune tâche n'est perdue en cas d'interruption réseau ou de dépassement de quota.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={toggleQueueRunning}
            className={`flex items-center space-x-2 font-semibold px-4 py-2 rounded-xl text-xs transition-all cursor-pointer ${
              isQueueRunning
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
            }`}
          >
            {isQueueRunning ? (
              <>
                <Pause className="w-4 h-4 fill-current" />
                <span>Mettre la file en pause</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>Reprendre l'exécution</span>
              </>
            )}
          </button>

          <button
            onClick={clearCompletedTasks}
            className="flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 px-3 py-2 rounded-xl text-xs transition-colors cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Purger terminées</span>
          </button>
        </div>
      </div>

      {/* Status Counters Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
        {[
          { label: 'Toutes', count: queueTasks.length, key: 'all', color: 'text-white' },
          { label: 'En cours', count: countByStatus.in_progress, key: 'in_progress', color: 'text-cyan-400' },
          { label: 'En attente', count: countByStatus.pending, key: 'pending', color: 'text-slate-300' },
          { label: 'Suspendues', count: countByStatus.suspended, key: 'suspended', color: 'text-amber-400' },
          { label: 'Terminées', count: countByStatus.completed, key: 'completed', color: 'text-emerald-400' },
          { label: 'En erreur', count: countByStatus.in_error, key: 'in_error', color: 'text-red-400' },
        ].map((item) => (
          <button
            key={item.key}
            onClick={() => setStatusFilter(item.key)}
            className={`p-3 rounded-xl border transition-all text-left cursor-pointer ${
              statusFilter === item.key
                ? 'bg-blue-600/15 border-blue-500/40 font-semibold'
                : 'bg-slate-900 border-slate-800 hover:border-slate-700'
            }`}
          >
            <span className="text-[10px] text-slate-400 block font-mono uppercase">{item.label}</span>
            <span className={`text-xl font-bold ${item.color}`}>{item.count}</span>
          </button>
        ))}
      </div>

      {/* Filter Bar & Search */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher une tâche..."
            className="w-full bg-slate-950 border border-slate-800 focus:border-blue-500 text-white rounded-lg pl-9 pr-3 py-2 focus:outline-none"
          />
        </div>

        <div className="flex items-center space-x-3 w-full sm:w-auto justify-end">
          <div className="flex items-center space-x-1.5">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-400">Moteur:</span>
          </div>

          <select
            value={engineFilter}
            onChange={(e) => setEngineFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 text-slate-300 rounded-lg px-2.5 py-1.5 focus:outline-none"
          >
            <option value="all">Tous les moteurs</option>
            <option value="wordpress">WordPress Content</option>
            <option value="woocommerce">WooCommerce Catalog</option>
            <option value="rankmath">Rank Math SEO</option>
            <option value="audit">Site Health Audit</option>
          </select>
        </div>
      </div>

      {/* Queue Tasks Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] uppercase border-b border-slate-800">
              <tr>
                <th className="p-3.5">ID / Priorité</th>
                <th className="p-3.5">Intitulé de la Tâche</th>
                <th className="p-3.5">Moteur Cible</th>
                <th className="p-3.5">Statut</th>
                <th className="p-3.5">Conformité Policy</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredTasks.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-500">
                    Aucune tâche dans la file d'exécution correspondant à ces filtres.
                  </td>
                </tr>
              ) : (
                filteredTasks.map((task) => (
                  <tr key={task.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="p-3.5 font-mono text-[11px] text-slate-400">
                      <div>{task.id}</div>
                      <span
                        className={`text-[9px] uppercase px-1.5 py-0.2 rounded ${
                          task.priority === 'high'
                            ? 'bg-red-500/20 text-red-300'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {task.priority}
                      </span>
                    </td>

                    <td className="p-3.5 font-medium text-white max-w-xs">
                      <div className="truncate">{task.title}</div>
                      {task.errorMessage && (
                        <span className="text-[10px] text-red-400 block truncate font-mono">
                          {task.errorMessage}
                        </span>
                      )}
                    </td>

                    <td className="p-3.5">{getEngineBadge(task.engine)}</td>

                    <td className="p-3.5">{getStatusBadge(task.status)}</td>

                    <td className="p-3.5">
                      {task.policyCompliance ? (
                        <div className="flex items-center space-x-1.5">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="font-mono text-emerald-400 text-[11px]">
                            {task.policyCompliance.score}%
                          </span>
                        </div>
                      ) : (
                        <span className="text-slate-500 font-mono text-[10px]">Non évalué</span>
                      )}
                    </td>

                    <td className="p-3.5 text-right space-x-1">
                      <button
                        onClick={() => setSelectedTask(task)}
                        className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-2.5 py-1 rounded-md text-[11px] transition-colors cursor-pointer"
                        title="Consulter les journaux d'exécution"
                      >
                        Logs
                      </button>

                      {task.status === 'pending' && (
                        <button
                          onClick={() => executeSingleTask(task.id)}
                          className="bg-blue-600 hover:bg-blue-500 text-white px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors cursor-pointer"
                        >
                          Lancer
                        </button>
                      )}

                      {(task.status === 'in_error' || task.status === 'suspended') && (
                        <button
                          onClick={() => retryTask(task.id)}
                          className="bg-amber-600 hover:bg-amber-500 text-white px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors cursor-pointer"
                        >
                          Relancer
                        </button>
                      )}

                      {task.status !== 'completed' && task.status !== 'cancelled' && (
                        <button
                          onClick={() => cancelTask(task.id)}
                          className="text-slate-500 hover:text-red-400 px-1.5 py-1 transition-colors cursor-pointer"
                          title="Annuler"
                        >
                          ✕
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Task Log Drawer Modal */}
      {selectedTask && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2">
                <Terminal className="w-5 h-5 text-cyan-400" />
                <h3 className="text-sm font-bold text-white font-mono">{selectedTask.id} - Journaux d'Exécution</h3>
              </div>
              <button
                onClick={() => setSelectedTask(null)}
                className="text-slate-400 hover:text-white font-bold text-xs"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-slate-400 font-mono">
                <span>Intitulé: {selectedTask.title}</span>
                <span>Moteur: {selectedTask.engine}</span>
              </div>

              {/* Console Logs Display */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-[11px] text-slate-300 space-y-1.5 max-h-64 overflow-y-auto">
                {selectedTask.logs.map((log, idx) => (
                  <div key={idx} className="leading-relaxed">
                    {log}
                  </div>
                ))}
              </div>

              {/* Result Preview if Completed */}
              {selectedTask.result && (
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2">
                  <h4 className="font-semibold text-emerald-400 text-xs flex items-center space-x-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Données Produite par le Moteur :</span>
                  </h4>
                  <pre className="text-[10px] text-slate-300 font-mono whitespace-pre-wrap max-h-40 overflow-y-auto">
                    {JSON.stringify(selectedTask.result, null, 2)}
                  </pre>
                </div>
              )}
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setSelectedTask(null)}
                className="bg-slate-800 hover:bg-slate-700 text-white font-medium px-4 py-1.5 rounded-lg text-xs cursor-pointer"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

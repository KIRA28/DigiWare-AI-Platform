import React, { useState } from 'react';
import { usePlatform } from '../context/PlatformContext';
import { WooProduct } from '../types';
import {
  ShoppingBag,
  Plus,
  Trash2,
  Edit3,
  Tag,
  Sparkles,
  TrendingUp,
  PackageCheck,
  CheckCircle2,
  RefreshCw,
} from 'lucide-react';

export const WooCommerceEngineView: React.FC = () => {
  const { wooProducts, createWooProduct, updateWooProduct, deleteWooProduct, addTasksToQueue, setActiveTab, wpConfig } = usePlatform();

  const [selectedProduct, setSelectedProduct] = useState<WooProduct | null>(null);
  const [showEditorModal, setShowEditorModal] = useState(false);

  // Sync Live State
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);

  // Form state
  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [price, setPrice] = useState<number>(0);
  const [regularPrice, setRegularPrice] = useState<number>(0);
  const [salePrice, setSalePrice] = useState<number | undefined>(undefined);
  const [stockStatus, setStockStatus] = useState<'instock' | 'outofstock' | 'onbackorder'>('instock');
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [shortDescription, setShortDescription] = useState('');
  const [seoTitle, setSeoTitle] = useState('');
  const [seoDesc, setSeoDesc] = useState('');

  const handleSyncLiveProducts = async () => {
    setIsSyncing(true);
    setSyncMessage(null);

    try {
      const res = await fetch('/api/wp/fetch-products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          siteUrl: wpConfig.siteUrl,
          username: wpConfig.username,
          appPassword: wpConfig.appPassword,
        }),
      });

      const data = await res.json();
      if (data.success && data.products) {
        data.products.forEach((prod: WooProduct) => createWooProduct(prod));
        setSyncMessage(`${data.count} produits synchronisés en direct depuis WooCommerce sur ${wpConfig.siteUrl} !`);
      } else {
        setSyncMessage(`Erreur de synchronisation WooCommerce : ${data.error || 'Vérifiez la connexion API'}`);
      }
    } catch (err: any) {
      setSyncMessage(`Erreur réseau : ${err.message}`);
    } finally {
      setIsSyncing(false);
    }
  };

  const openNewProductForm = () => {
    setSelectedProduct(null);
    setName('');
    setSku(`DIGI-${Math.floor(1000 + Math.random() * 9000)}`);
    setPrice(199);
    setRegularPrice(229);
    setSalePrice(199);
    setStockStatus('instock');
    setCategory('Équipements');
    setDescription('');
    setShortDescription('');
    setSeoTitle('');
    setSeoDesc('');
    setShowEditorModal(true);
  };

  const openEditProductForm = (product: WooProduct) => {
    setSelectedProduct(product);
    setName(product.name);
    setSku(product.sku);
    setPrice(product.price);
    setRegularPrice(product.regularPrice);
    setSalePrice(product.salePrice);
    setStockStatus(product.stockStatus);
    setCategory(product.category);
    setDescription(product.description);
    setShortDescription(product.shortDescription);
    setSeoTitle(product.seoTitle);
    setSeoDesc(product.seoDesc);
    setShowEditorModal(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    const productPayload = {
      name,
      sku,
      price,
      regularPrice,
      salePrice: salePrice || price,
      stockStatus,
      category,
      description,
      shortDescription,
      attributes: { 'Garantie': '2 ans', 'Origine': 'France' },
      seoTitle: seoTitle || name,
      seoDesc: seoDesc || shortDescription,
      score: Math.floor(78 + Math.random() * 20),
    };

    if (selectedProduct) {
      updateWooProduct({ ...selectedProduct, ...productPayload });
    } else {
      createWooProduct(productPayload);
    }

    setShowEditorModal(false);
  };

  const handleTriggerAiOptimization = (product: WooProduct) => {
    addTasksToQueue([
      {
        title: `Enrichissement Fiche WooCommerce : ${product.name}`,
        engine: 'woocommerce',
        status: 'pending',
        priority: 'high',
        payload: { productId: product.id, sku: product.sku },
      },
    ]);
    setActiveTab('queue');
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto text-slate-200">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-mono px-2.5 py-0.5 rounded-full font-semibold">
              E-Commerce Catalogue Engine
            </span>
            <span className="text-xs text-slate-400 font-mono">
              WooCommerce REST API
            </span>
          </div>
          <h1 className="text-2xl font-bold text-white flex items-center space-x-2">
            <ShoppingBag className="w-6 h-6 text-emerald-400" />
            <span>WooCommerce Catalog Engine</span>
          </h1>
          <p className="text-xs text-slate-400 max-w-2xl">
            Optimisez et enrichissez votre catalogue produit WooCommerce : descriptions persuasives, attributs techniques et snippets Rank Math.
          </p>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          <button
            onClick={handleSyncLiveProducts}
            disabled={isSyncing}
            className="flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-emerald-300 font-semibold px-3.5 py-2.5 rounded-xl shadow-lg transition-all text-xs cursor-pointer disabled:opacity-50"
            title="Importer le catalogue réel depuis le WooCommerce distant"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Synchronisation...' : 'Synchroniser Catalogue Réel'}</span>
          </button>

          <button
            onClick={openNewProductForm}
            className="flex items-center space-x-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-semibold px-4 py-2.5 rounded-xl shadow-lg transition-all text-xs cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Ajouter un Produit</span>
          </button>
        </div>
      </div>

      {syncMessage && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 rounded-xl text-xs flex items-center justify-between font-mono">
          <span>{syncMessage}</span>
          <button onClick={() => setSyncMessage(null)} className="text-emerald-400 font-bold hover:text-white">✕</button>
        </div>
      )}

      {/* Products Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] uppercase border-b border-slate-800">
              <tr>
                <th className="p-3.5">Produit / SKU</th>
                <th className="p-3.5">Catégorie</th>
                <th className="p-3.5">Prix (€)</th>
                <th className="p-3.5">Stock</th>
                <th className="p-3.5">Score Qualité</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {wooProducts.map((prod) => (
                <tr key={prod.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-3.5 max-w-xs">
                    <div className="font-semibold text-white truncate">{prod.name}</div>
                    <div className="text-[10px] text-slate-500 font-mono">SKU: {prod.sku}</div>
                  </td>

                  <td className="p-3.5 font-mono text-[11px] text-slate-300">
                    {prod.category}
                  </td>

                  <td className="p-3.5 font-mono text-slate-200">
                    <div className="flex items-baseline space-x-1.5">
                      <span className="font-bold text-emerald-400">{prod.price} €</span>
                      {prod.regularPrice > prod.price && (
                        <span className="text-[10px] text-slate-500 line-through">
                          {prod.regularPrice} €
                        </span>
                      )}
                    </div>
                  </td>

                  <td className="p-3.5">
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded capitalize ${
                        prod.stockStatus === 'instock'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : 'bg-red-500/10 text-red-400 border border-red-500/20'
                      }`}
                    >
                      {prod.stockStatus === 'instock' ? 'En stock' : 'Rupture'}
                    </span>
                  </td>

                  <td className="p-3.5">
                    <div className="flex items-center space-x-1.5 font-mono">
                      <PackageCheck className="w-3.5 h-3.5 text-cyan-400" />
                      <span className="font-bold text-cyan-400">{prod.score}/100</span>
                    </div>
                  </td>

                  <td className="p-3.5 text-right space-x-1">
                    <button
                      onClick={() => handleTriggerAiOptimization(prod)}
                      className="bg-emerald-600/20 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-600/30 px-2 py-1 rounded text-[11px] cursor-pointer"
                      title="Enrichir par l'IA"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => openEditProductForm(prod)}
                      className="bg-blue-600/20 text-blue-300 border border-blue-500/30 hover:bg-blue-600/30 px-2 py-1 rounded text-[11px] cursor-pointer"
                    >
                      Éditer
                    </button>

                    <button
                      onClick={() => deleteWooProduct(prod.id)}
                      className="text-slate-500 hover:text-red-400 px-1.5 py-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Product Editor Modal */}
      {showEditorModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-3xl w-full space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <ShoppingBag className="w-5 h-5 text-emerald-400" />
                <span>{selectedProduct ? 'Éditer Fiche Produit WooCommerce' : 'Ajouter un Produit WooCommerce'}</span>
              </h3>
              <button
                onClick={() => setShowEditorModal(false)}
                className="text-slate-400 hover:text-white font-bold text-xs"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-slate-300 font-medium mb-1">Nom du Produit</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="ex: VTT Électrique DigiBike Trail Pro"
                    className="w-full bg-slate-950 border border-slate-800 text-white p-2.5 rounded-lg focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">SKU Produit</label>
                  <input
                    type="text"
                    value={sku}
                    onChange={(e) => setSku(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-white p-2.5 rounded-lg focus:outline-none font-mono"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Prix de Vente (€)</label>
                  <input
                    type="number"
                    value={price}
                    onChange={(e) => setPrice(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 text-white p-2.5 rounded-lg focus:outline-none font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Prix Régulier (€)</label>
                  <input
                    type="number"
                    value={regularPrice}
                    onChange={(e) => setRegularPrice(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 text-white p-2.5 rounded-lg focus:outline-none font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Catégorie</label>
                  <input
                    type="text"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-white p-2.5 rounded-lg focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Courte Description (Accroche)</label>
                <textarea
                  value={shortDescription}
                  onChange={(e) => setShortDescription(e.target.value)}
                  placeholder="3 points clés et bénéfices produit..."
                  rows={2}
                  className="w-full bg-slate-950 border border-slate-800 text-white p-2.5 rounded-lg focus:outline-none resize-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Description Complète WooCommerce</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Spécifications détaillées, conseils d'utilisation et garantie..."
                  rows={5}
                  className="w-full bg-slate-950 border border-slate-800 text-white p-2.5 rounded-lg focus:outline-none resize-none font-mono text-xs"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowEditorModal(false)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold cursor-pointer"
                >
                  Enregistrer la Fiche Produit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

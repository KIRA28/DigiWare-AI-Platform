import React, { useState } from 'react';
import { usePlatform } from '../context/PlatformContext';
import {
  CalendarDays,
  Clock,
  Layers,
  Sparkles,
  Plus,
  Play,
  CheckCircle2,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Sliders,
} from 'lucide-react';

export const SchedulerView: React.FC = () => {
  const { scheduledSlots, addScheduledSlot, queueTasks, addTasksToQueue } = usePlatform();

  const [selectedDate, setSelectedDate] = useState<string>('2026-08-06');
  const [showAutoDistributeModal, setShowAutoDistributeModal] = useState(false);
  const [postCount, setPostCount] = useState<number>(50);
  const [spreadDays, setSpreadDays] = useState<number>(14);

  const handleAutoDistribute = (e: React.FormEvent) => {
    e.preventDefault();

    // Generate spread tasks and schedule slots
    const generatedTasks = [];
    for (let i = 1; i <= Math.min(postCount, 100); i++) {
      const dayOffset = Math.floor(i / (postCount / spreadDays));
      const scheduledDateObj = new Date();
      scheduledDateObj.setDate(scheduledDateObj.getDate() + dayOffset);
      const formattedDate = scheduledDateObj.toISOString().split('T')[0];

      generatedTasks.push({
        title: `Publication Programmée #${i} - Gamme VTT Électriques 2026`,
        engine: i % 2 === 0 ? ('wordpress' as const) : ('woocommerce' as const),
        status: 'pending' as const,
        priority: 'medium' as const,
        payload: { batchIndex: i, scheduledDate: formattedDate },
        scheduledAt: formattedDate,
      });

      addScheduledSlot({
        taskId: `task-sched-${i}`,
        taskTitle: `Publication Programmée #${i}`,
        engine: i % 2 === 0 ? 'wordpress' : 'woocommerce',
        scheduledDate: formattedDate,
        timeSlot: `${9 + (i % 8)}:00`,
        status: 'scheduled',
      });
    }

    addTasksToQueue(generatedTasks);
    setShowAutoDistributeModal(false);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto text-slate-200">
      {/* Title Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-xs font-mono px-2.5 py-0.5 rounded-full font-semibold">
              Orchestrateur Temporel Intelligent
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Lissage de Charge Quotas
            </span>
          </div>
          <h1 className="text-2xl font-bold text-white flex items-center space-x-2">
            <CalendarDays className="w-6 h-6 text-indigo-400" />
            <span>Scheduler (Gestionnaire du Temps)</span>
          </h1>
          <p className="text-xs text-slate-400 max-w-2xl">
            Le Scheduler planifie et lisse l'exécution des tâches volumineuses (ex: 1000 articles) sur plusieurs jours ou semaines afin d'éviter le dépassement des quotas d'API et d'assurer une cadence régulière.
          </p>
        </div>

        <button
          onClick={() => setShowAutoDistributeModal(true)}
          className="flex items-center space-x-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-semibold px-4 py-2.5 rounded-xl shadow-lg transition-all text-xs cursor-pointer shrink-0"
        >
          <Sparkles className="w-4 h-4" />
          <span>Planificateur Automatique</span>
        </button>
      </div>

      {/* Calendar & Slot Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Date Selector List */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-semibold text-white flex items-center space-x-2">
            <Calendar className="w-4 h-4 text-indigo-400" />
            <span>Calendrier de Publication</span>
          </h3>

          <div className="space-y-2">
            {['2026-08-06', '2026-08-07', '2026-08-08', '2026-08-09', '2026-08-10'].map((dateStr) => {
              const countForDate = scheduledSlots.filter((s) => s.scheduledDate === dateStr).length;
              return (
                <button
                  key={dateStr}
                  onClick={() => setSelectedDate(dateStr)}
                  className={`w-full flex items-center justify-between p-3 rounded-xl border text-xs transition-all cursor-pointer ${
                    selectedDate === dateStr
                      ? 'bg-indigo-600/20 border-indigo-500/50 text-white font-semibold shadow-sm'
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <span className="font-mono">{dateStr}</span>
                  <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono text-[10px]">
                    {countForDate} créneaux
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Timeline Slot Details */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 lg:col-span-2">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white font-mono">
              Créneaux Programmés pour le {selectedDate}
            </h3>
            <span className="text-xs text-indigo-400 font-mono">
              {scheduledSlots.filter((s) => s.scheduledDate === selectedDate).length} tâches planifiées
            </span>
          </div>

          <div className="space-y-2">
            {scheduledSlots.filter((s) => s.scheduledDate === selectedDate).length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs">
                Aucune tâche planifiée pour cette date. Utilisez le planificateur automatique.
              </div>
            ) : (
              scheduledSlots
                .filter((s) => s.scheduledDate === selectedDate)
                .map((slot) => (
                  <div
                    key={slot.id}
                    className="p-3 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="font-mono text-cyan-400 font-semibold text-xs bg-slate-900 px-2 py-1 rounded border border-slate-800">
                        {slot.timeSlot}
                      </div>
                      <div>
                        <h4 className="text-white font-medium">{slot.taskTitle}</h4>
                        <span className="text-[10px] text-slate-500 uppercase font-mono">
                          Moteur: {slot.engine}
                        </span>
                      </div>
                    </div>

                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded capitalize ${
                        slot.status === 'running'
                          ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                          : slot.status === 'completed'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : 'bg-slate-800 text-slate-400 border border-slate-700'
                      }`}
                    >
                      {slot.status === 'running' ? 'En cours' : slot.status}
                    </span>
                  </div>
                ))
            )}
          </div>
        </div>
      </div>

      {/* Auto Distribute Modal */}
      {showAutoDistributeModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <Sliders className="w-5 h-5 text-indigo-400" />
                <span>Répartition Étalée Automatique</span>
              </h3>
              <button
                onClick={() => setShowAutoDistributeModal(false)}
                className="text-slate-400 hover:text-white font-bold text-xs"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAutoDistribute} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Nombre de contenus/tâches</label>
                <input
                  type="number"
                  value={postCount}
                  onChange={(e) => setPostCount(Number(e.target.value))}
                  min={1}
                  max={500}
                  className="w-full bg-slate-950 border border-slate-800 text-white p-2.5 rounded-lg focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Période d'étalement (Jours)</label>
                <input
                  type="number"
                  value={spreadDays}
                  onChange={(e) => setSpreadDays(Number(e.target.value))}
                  min={1}
                  max={60}
                  className="w-full bg-slate-950 border border-slate-800 text-white p-2.5 rounded-lg focus:outline-none"
                  required
                />
              </div>

              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-[11px] text-slate-400 space-y-1">
                <div className="font-semibold text-white">Lissage Calculé :</div>
                <div>~{Math.ceil(postCount / spreadDays)} publications par jour.</div>
                <div>Garantie du respect des limites d'API et des quotas horaires.</div>
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowAutoDistributeModal(false)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold cursor-pointer"
                >
                  Générer le Planning
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

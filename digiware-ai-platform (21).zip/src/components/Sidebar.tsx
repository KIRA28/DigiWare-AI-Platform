import React from 'react';
import { usePlatform } from '../context/PlatformContext';
import {
  LayoutDashboard,
  Brain,
  Layers,
  FileCheck2,
  ShieldCheck,
  CalendarDays,
  FileText,
  ShoppingBag,
  Search,
  Activity,
  Settings,
  ChevronRight,
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, queueTasks, policyRules, siteAudit } = usePlatform();

  const pendingQueueCount = queueTasks.filter((t) => t.status === 'pending' || t.status === 'in_progress').length;
  const completedTaskCount = queueTasks.filter((t) => t.status === 'completed' || t.status === 'in_error' || t.result).length;
  const criticalAuditIssues = siteAudit.issues.filter((i) => i.severity === 'critical').length;

  const navGroups = [
    {
      title: 'CENTRE DE CONTRÔLE',
      items: [
        {
          id: 'dashboard',
          label: 'Aperçu Général',
          icon: LayoutDashboard,
          badge: null,
        },
        {
          id: 'workspace',
          label: 'AI Workspace (Cerveau)',
          icon: Brain,
          badge: 'IA',
          badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
        },
        {
          id: 'queue',
          label: 'Queue Manager',
          icon: Layers,
          badge: pendingQueueCount > 0 ? `${pendingQueueCount}` : null,
          badgeColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
        },
        {
          id: 'results',
          label: 'Rapports & Résultats',
          icon: FileCheck2,
          badge: completedTaskCount > 0 ? `${completedTaskCount}` : null,
          badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
        },
      ],
    },
    {
      title: 'STRATÉGIE & GOUVERNANCE',
      items: [
        {
          id: 'policy',
          label: 'Policy Engine',
          icon: ShieldCheck,
          badge: `${policyRules.filter((r) => r.active).length} règles`,
          badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
        },
        {
          id: 'scheduler',
          label: 'Scheduler (Planning)',
          icon: CalendarDays,
          badge: null,
        },
      ],
    },
    {
      title: 'MOTEURS DE PRODUCTION',
      items: [
        {
          id: 'wordpress',
          label: 'WordPress Content',
          icon: FileText,
          badge: null,
        },
        {
          id: 'woocommerce',
          label: 'Catalogue WooCommerce',
          icon: ShoppingBag,
          badge: null,
        },
        {
          id: 'rankmath',
          label: 'Rank Math SEO Engine',
          icon: Search,
          badge: null,
        },
        {
          id: 'audit',
          label: 'Santé & Audit Site',
          icon: Activity,
          badge: criticalAuditIssues > 0 ? `${criticalAuditIssues} alertes` : null,
          badgeColor: 'bg-red-500/20 text-red-300 border-red-500/30',
        },
      ],
    },
    {
      title: 'CONFIGURATION',
      items: [
        {
          id: 'settings',
          label: 'WP Connection & APIs',
          icon: Settings,
          badge: null,
        },
      ],
    },
  ];

  return (
    <aside className="w-full md:w-64 bg-slate-900 border-r border-slate-800 text-slate-300 flex flex-col shrink-0">
      <div className="p-4 space-y-6 overflow-y-auto flex-1">
        {navGroups.map((group, idx) => (
          <div key={idx} className="space-y-1">
            <h3 className="px-3 text-[11px] font-semibold text-slate-500 uppercase tracking-wider font-mono">
              {group.title}
            </h3>
            <div className="mt-1 space-y-0.5">
              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                      isActive
                        ? 'bg-blue-600/15 text-white border border-blue-500/30 font-semibold shadow-sm'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5 min-w-0">
                      <Icon
                        className={`w-4 h-4 shrink-0 ${
                          isActive ? 'text-blue-400' : 'text-slate-500'
                        }`}
                      />
                      <span className="truncate">{item.label}</span>
                    </div>

                    <div className="flex items-center space-x-1 shrink-0">
                      {item.badge && (
                        <span
                          className={`text-[10px] font-mono px-1.5 py-0.5 rounded border ${
                            item.badgeColor || 'bg-slate-800 text-slate-300 border-slate-700'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                      {isActive && <ChevronRight className="w-3.5 h-3.5 text-blue-400" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Footer Info Box */}
      <div className="p-4 border-t border-slate-800/80 bg-slate-950/40 text-xs">
        <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono mb-1">
          <span>DigiWare Core</span>
          <span className="text-emerald-400">En Ligne</span>
        </div>
        <p className="text-[10px] text-slate-500 leading-relaxed">
          Toutes les opérations sont orchestrées en arrière-plan sans blocage du serveur.
        </p>
      </div>
    </aside>
  );
};

import React, { useState } from 'react';
import { usePlatform } from '../context/PlatformContext';
import { WordPressPost } from '../types';
import {
  FileText,
  Plus,
  Trash2,
  Edit3,
  Globe,
  Search,
  CheckCircle2,
  Eye,
  Sparkles,
  TrendingUp,
  RefreshCw,
  ExternalLink,
} from 'lucide-react';

export const WordPressEngineView: React.FC = () => {
  const { wpPosts, createWPPost, updateWPPost, deleteWPPost, addTasksToQueue, setActiveTab, wpConfig } = usePlatform();

  const [selectedPost, setSelectedPost] = useState<WordPressPost | null>(null);
  const [showEditorModal, setShowEditorModal] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false);

  // Sync Live State
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);

  // Form state
  const [title, setTitle] = useState('');
  const [slug, setSlug] = useState('');
  const [content, setContent] = useState('');
  const [excerpt, setExcerpt] = useState('');
  const [status, setStatus] = useState<'draft' | 'publish'>('draft');
  const [focusKeyword, setFocusKeyword] = useState('');
  const [metaTitle, setMetaTitle] = useState('');
  const [metaDescription, setMetaDescription] = useState('');
  const [isPublishingLive, setIsPublishingLive] = useState(false);

  const handleSyncLivePosts = async () => {
    setIsSyncing(true);
    setSyncMessage(null);

    try {
      const res = await fetch('/api/wp/fetch-posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          siteUrl: wpConfig.siteUrl,
          username: wpConfig.username,
          appPassword: wpConfig.appPassword,
        }),
      });

      const data = await res.json();
      if (data.success && data.posts) {
        data.posts.forEach((p: WordPressPost) => createWPPost(p));
        setSyncMessage(`${data.count} articles récupérés en direct depuis ${wpConfig.siteUrl} !`);
      } else {
        setSyncMessage(`Erreur de synchronisation : ${data.error || 'Erreur inconnue'}`);
      }
    } catch (err: any) {
      setSyncMessage(`Erreur réseau : ${err.message}`);
    } finally {
      setIsSyncing(false);
    }
  };

  const openNewPostForm = () => {
    setSelectedPost(null);
    setTitle('');
    setSlug('');
    setContent('');
    setExcerpt('');
    setStatus('draft');
    setFocusKeyword('');
    setMetaTitle('');
    setMetaDescription('');
    setShowEditorModal(true);
  };

  const openEditPostForm = (post: WordPressPost) => {
    setSelectedPost(post);
    setTitle(post.title);
    setSlug(post.slug);
    setContent(post.content);
    setExcerpt(post.excerpt);
    setStatus(post.status === 'future' ? 'draft' : post.status);
    setFocusKeyword(post.focusKeyword);
    setMetaTitle(post.metaTitle);
    setMetaDescription(post.metaDescription);
    setShowEditorModal(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();

    const postPayload = {
      title,
      slug: slug || title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      content,
      excerpt,
      status,
      categories: ['Blog'],
      tags: [focusKeyword || 'SEO'],
      seoScore: Math.floor(75 + Math.random() * 20),
      focusKeyword,
      metaTitle: metaTitle || title,
      metaDescription: metaDescription || excerpt,
    };

    if (wpConfig.mode === 'live' && wpConfig.username && wpConfig.appPassword) {
      setIsPublishingLive(true);
      try {
        const res = await fetch('/api/wp/create-post', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            siteUrl: wpConfig.siteUrl,
            username: wpConfig.username,
            appPassword: wpConfig.appPassword,
            post: postPayload,
          }),
        });

        const liveData = await res.json();
        if (liveData.success) {
          createWPPost({
            ...postPayload,
            id: `live-${liveData.wpId}`,
            updatedAt: new Date().toISOString().substring(0, 10),
          });
        }
      } catch (err) {
        console.error('Publish error', err);
      } finally {
        setIsPublishingLive(false);
      }
    } else {
      if (selectedPost) {
        updateWPPost({ ...selectedPost, ...postPayload });
      } else {
        createWPPost(postPayload);
      }
    }

    setShowEditorModal(false);
  };

  const handleTriggerAiOptimization = (post: WordPressPost) => {
    addTasksToQueue([
      {
        title: `Optimisation SEO Rank Math : ${post.title}`,
        engine: 'wordpress',
        status: 'pending',
        priority: 'high',
        payload: { postId: post.id, focusKeyword: post.focusKeyword },
      },
    ]);
    setActiveTab('queue');
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto text-slate-200">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="bg-blue-500/10 text-blue-400 border border-blue-500/20 text-xs font-mono px-2.5 py-0.5 rounded-full font-semibold">
              Moteur de Production SEO
            </span>
            <span className="text-xs text-slate-400 font-mono">
              WordPress REST API
            </span>
          </div>
          <h1 className="text-2xl font-bold text-white flex items-center space-x-2">
            <FileText className="w-6 h-6 text-blue-400" />
            <span>WordPress Content Engine</span>
          </h1>
          <p className="text-xs text-slate-400 max-w-2xl">
            Gérez vos articles de blog, guides piliers et pages de catégories. Chaque contenu est automatiquement analysé par le moteur Rank Math.
          </p>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          <button
            onClick={handleSyncLivePosts}
            disabled={isSyncing}
            className="flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-cyan-300 font-semibold px-3.5 py-2.5 rounded-xl shadow-lg transition-all text-xs cursor-pointer disabled:opacity-50"
            title="Importer la liste d'articles réels depuis le WordPress distant"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Synchronisation...' : 'Synchroniser Site Réel WP'}</span>
          </button>

          <button
            onClick={openNewPostForm}
            className="flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold px-4 py-2.5 rounded-xl shadow-lg transition-all text-xs cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Rédiger un Article</span>
          </button>
        </div>
      </div>

      {syncMessage && (
        <div className="p-3 bg-cyan-950/60 border border-cyan-500/40 text-cyan-300 rounded-xl text-xs flex items-center justify-between font-mono">
          <span>{syncMessage}</span>
          <button onClick={() => setSyncMessage(null)} className="text-cyan-400 font-bold hover:text-white">✕</button>
        </div>
      )}

      {/* Posts Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] uppercase border-b border-slate-800">
              <tr>
                <th className="p-3.5">Titre / Slug</th>
                <th className="p-3.5">Statut</th>
                <th className="p-3.5">Mot-Clé Cible</th>
                <th className="p-3.5">Score Rank Math</th>
                <th className="p-3.5">Dernière maj</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {wpPosts.map((post) => (
                <tr key={post.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-3.5 max-w-xs">
                    <div className="font-semibold text-white truncate">{post.title}</div>
                    <div className="text-[10px] text-slate-500 font-mono truncate">/{post.slug}</div>
                  </td>

                  <td className="p-3.5">
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded capitalize ${
                        post.status === 'publish'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                      }`}
                    >
                      {post.status === 'publish' ? 'Publié' : 'Brouillon'}
                    </span>
                  </td>

                  <td className="p-3.5 font-mono text-[11px] text-slate-300">
                    {post.focusKeyword || '-'}
                  </td>

                  <td className="p-3.5">
                    <div className="flex items-center space-x-1.5 font-mono">
                      <TrendingUp className="w-3.5 h-3.5 text-purple-400" />
                      <span
                        className={`font-bold ${
                          post.seoScore >= 80
                            ? 'text-emerald-400'
                            : post.seoScore >= 60
                            ? 'text-amber-400'
                            : 'text-red-400'
                        }`}
                      >
                        {post.seoScore}/100
                      </span>
                    </div>
                  </td>

                  <td className="p-3.5 text-[10px] text-slate-400 font-mono">{post.updatedAt}</td>

                  <td className="p-3.5 text-right space-x-1">
                    <button
                      onClick={() => {
                        setSelectedPost(post);
                        setShowPreviewModal(true);
                      }}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded text-[11px] cursor-pointer"
                      title="Aperçu HTML"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => handleTriggerAiOptimization(post)}
                      className="bg-indigo-600/20 text-indigo-300 border border-indigo-500/30 hover:bg-indigo-600/30 px-2 py-1 rounded text-[11px] cursor-pointer"
                      title="Optimiser par l'IA"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => openEditPostForm(post)}
                      className="bg-blue-600/20 text-blue-300 border border-blue-500/30 hover:bg-blue-600/30 px-2 py-1 rounded text-[11px] cursor-pointer"
                    >
                      Éditer
                    </button>

                    <button
                      onClick={() => deleteWPPost(post.id)}
                      className="text-slate-500 hover:text-red-400 px-1.5 py-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Editor Modal */}
      {showEditorModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-3xl w-full space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <FileText className="w-5 h-5 text-blue-400" />
                <span>{selectedPost ? 'Éditer l\'Article WordPress' : 'Rédiger un Nouvel Article'}</span>
              </h3>
              <button
                onClick={() => setShowEditorModal(false)}
                className="text-slate-400 hover:text-white font-bold text-xs"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Titre de l'Article</label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="ex: Guide complet VTT Électrique 2026"
                    className="w-full bg-slate-950 border border-slate-800 text-white p-2.5 rounded-lg focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Slug URL</label>
                  <input
                    type="text"
                    value={slug}
                    onChange={(e) => setSlug(e.target.value)}
                    placeholder="ex: guide-vtt-electrique-2026"
                    className="w-full bg-slate-950 border border-slate-800 text-white p-2.5 rounded-lg focus:outline-none font-mono text-[11px]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Contenu HTML / Texte</label>
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Contenu complet de l'article avec balises HTML H2/H3..."
                  rows={8}
                  className="w-full bg-slate-950 border border-slate-800 text-white p-3 rounded-lg focus:outline-none font-mono text-xs resize-none"
                  required
                />
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                <h4 className="font-semibold text-purple-400 flex items-center space-x-1.5">
                  <TrendingUp className="w-4 h-4" />
                  <span>Champs Rank Math SEO</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-400 mb-1">Mot-clé Principal Target</label>
                    <input
                      type="text"
                      value={focusKeyword}
                      onChange={(e) => setFocusKeyword(e.target.value)}
                      placeholder="ex: VTT électrique 2026"
                      className="w-full bg-slate-900 border border-slate-800 text-white p-2 rounded focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Statut Publication</label>
                    <select
                      value={status}
                      onChange={(e) => setStatus(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-800 text-white p-2 rounded focus:outline-none"
                    >
                      <option value="draft">Brouillon</option>
                      <option value="publish">Publié</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Meta Title (SERP Google)</label>
                  <input
                    type="text"
                    value={metaTitle}
                    onChange={(e) => setMetaTitle(e.target.value)}
                    placeholder="ex: Guide d'Achat VTT Électrique 2026 | Conseils Expert"
                    className="w-full bg-slate-900 border border-slate-800 text-white p-2 rounded focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Meta Description</label>
                  <textarea
                    value={metaDescription}
                    onChange={(e) => setMetaDescription(e.target.value)}
                    placeholder="Extrait accrocheur pour les résultats de recherche..."
                    rows={2}
                    className="w-full bg-slate-900 border border-slate-800 text-white p-2 rounded focus:outline-none resize-none"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowEditorModal(false)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold cursor-pointer"
                >
                  Enregistrer l'Article
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Preview Modal */}
      {showPreviewModal && selectedPost && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-3xl w-full space-y-4 shadow-2xl max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white">{selectedPost.title}</h3>
                <p className="text-xs text-slate-400 font-mono">/{selectedPost.slug}</p>
              </div>
              <button
                onClick={() => setShowPreviewModal(false)}
                className="text-slate-400 hover:text-white font-bold text-xs"
              >
                ✕
              </button>
            </div>

            <div className="bg-white text-slate-900 p-6 rounded-xl font-sans leading-relaxed text-xs space-y-3 max-h-96 overflow-y-auto">
              <div dangerouslySetInnerHTML={{ __html: selectedPost.content }} />
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setShowPreviewModal(false)}
                className="bg-slate-800 text-white font-medium px-4 py-1.5 rounded-lg text-xs cursor-pointer"
              >
                Fermer l'Aperçu
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

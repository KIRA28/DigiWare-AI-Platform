import React, { useState } from 'react';
import { usePlatform } from '../context/PlatformContext';
import { ExportModal } from './ExportModal';
import {
  Brain,
  Play,
  Pause,
  Globe,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Clock,
  Layers,
  Settings,
  Download,
} from 'lucide-react';

export const Header: React.FC = () => {
  const {
    wpConfig,
    isQueueRunning,
    toggleQueueRunning,
    queueTasks,
    setActiveTab,
    policyRules,
  } = usePlatform();

  const [isExportOpen, setIsExportOpen] = useState(false);

  const pendingCount = queueTasks.filter((t) => t.status === 'pending').length;
  const inProgressCount = queueTasks.filter((t) => t.status === 'in_progress').length;
  const activeRulesCount = policyRules.filter((r) => r.active).length;

  return (
    <>
      <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-40 px-4 py-3 shadow-md">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* Logo & Brand */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-400 p-0.5 shadow-lg shadow-blue-500/20 flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Brain className="w-5 h-5 text-cyan-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-lg tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-slate-200 to-slate-400">
                  DigiWare AI
                </span>
                <span className="bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 text-[10px] font-mono px-1.5 py-0.5 rounded-md font-semibold">
                  V1.0
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium hidden sm:block">
                Système d'Exploitation WordPress & WooCommerce
              </p>
            </div>
          </div>

          {/* Status Indicators & Control Center */}
          <div className="flex flex-wrap items-center justify-end gap-2 sm:gap-3 text-xs">
            {/* Active Site Indicator */}
            <div
              onClick={() => setActiveTab('settings')}
              className="flex items-center space-x-2 bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 px-3 py-1.5 rounded-lg cursor-pointer transition-colors"
              title="Gérer les identifiants WordPress & REST API"
            >
              <Globe className="w-3.5 h-3.5 text-blue-400" />
              <span className="text-slate-300 font-medium truncate max-w-[140px] sm:max-w-[180px]">
                {wpConfig.siteUrl.replace('https://', '').replace('http://', '')}
              </span>
              <span
                className={`w-2 h-2 rounded-full ${
                  wpConfig.mode === 'live' ? 'bg-emerald-400 animate-pulse' : 'bg-cyan-400'
                }`}
                title={wpConfig.mode === 'live' ? 'Mode Direct WordPress' : 'Mode Simulation'}
              ></span>
            </div>

            {/* Export ZIP Package Button */}
            <button
              onClick={() => setIsExportOpen(true)}
              className="flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-750 border border-slate-700/80 text-cyan-300 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
              title="Télécharger le fichier ZIP pour une autre IA"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span className="font-semibold">Export ZIP</span>
            </button>

            {/* Active Policy Rules Badge */}
            <div
              onClick={() => setActiveTab('policy')}
              className="hidden md:flex items-center space-x-1.5 bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 px-2.5 py-1.5 rounded-lg cursor-pointer transition-colors text-slate-300"
              title="Gardien de la stratégie"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>Policy Engine: <strong className="text-white">{activeRulesCount}</strong> règles</span>
            </div>

            {/* Queue Engine Runner Control */}
            <div className="flex items-center bg-slate-800 border border-slate-700/80 rounded-lg p-1 space-x-2">
              <div className="flex items-center space-x-1.5 px-2">
                <Layers className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-slate-300 font-medium">
                  Queue: <span className="text-cyan-300 font-bold">{pendingCount + inProgressCount}</span>
                </span>
              </div>

              <button
                onClick={toggleQueueRunning}
                className={`flex items-center space-x-1 px-2.5 py-1 rounded-md font-medium text-xs transition-all ${
                  isQueueRunning
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
                }`}
              >
                {isQueueRunning ? (
                  <>
                    <Pause className="w-3 h-3 fill-current" />
                    <span>Suspendre</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3 h-3 fill-current" />
                    <span>Activer</span>
                  </>
                )}
              </button>
            </div>

            {/* Express Goal Trigger */}
            <button
              onClick={() => setActiveTab('workspace')}
              className="flex items-center space-x-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-medium px-3 py-1.5 rounded-lg shadow-md shadow-blue-600/20 transition-all cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Définir Objectif</span>
            </button>
          </div>
        </div>
      </header>

      <ExportModal isOpen={isExportOpen} onClose={() => setIsExportOpen(false)} />
    </>
  );
};


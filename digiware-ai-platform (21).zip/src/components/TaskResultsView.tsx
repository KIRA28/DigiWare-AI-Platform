import React, { useState } from 'react';
import { usePlatform } from '../context/PlatformContext';
import {
  FileCheck2,
  Clock,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Search,
  Filter,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
  FileText,
  ShoppingBag,
  Search as SearchIcon,
  Activity,
  Layers,
  Sparkles,
} from 'lucide-react';
import { QueueTask, EngineType } from '../types';

export const TaskResultsView: React.FC = () => {
  const { queueTasks, wpConfig } = usePlatform();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEngine, setSelectedEngine] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [expandedTaskId, setExpandedTaskId] = useState<string | null>(null);
  const [copiedTaskId, setCopiedTaskId] = useState<string | null>(null);

  // Filter tasks with execution reports (completed or in_error)
  const reportTasks = queueTasks.filter(
    (t) => t.status === 'completed' || t.status === 'in_error' || t.result
  );

  const filteredTasks = reportTasks.filter((task) => {
    const matchesSearch =
      task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.engine.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesEngine = selectedEngine === 'all' || task.engine === selectedEngine;
    const matchesStatus = selectedStatus === 'all' || task.status === selectedStatus;
    return matchesSearch && matchesEngine && matchesStatus;
  });

  const completedCount = reportTasks.filter((t) => t.status === 'completed').length;
  const errorCount = reportTasks.filter((t) => t.status === 'in_error').length;

  const handleCopyReport = (task: QueueTask) => {
    const res = task.result || {};
    const createdStr = (res.itemsCreated || [])
      .map((i: any) => `- [CRÉÉ] ${i.title} (${i.type}) -> ${i.link}`)
      .join('\n');
    const modifiedStr = (res.itemsModified || [])
      .map((i: any) => `- [MODIFIÉ] ${i.title} (${i.type}) -> ${i.link}`)
      .join('\n');
    const ignoredStr = (res.itemsIgnored || [])
      .map((i: any) => `- [IGNORÉ] ${i.title} (Raison: ${i.reason})`)
      .join('\n');
    const warningsStr = (res.warnings || []).map((w: string) => `- ⚠️ ${w}`).join('\n');
    const logsStr = (task.logs || []).join('\n');

    const markdownReport = `### Rapport d'Exécution DigiWare AI
**Tâche** : ${task.title}
**Moteur** : ${task.engine.toUpperCase()}
**Statut** : ${task.status.toUpperCase()}
**Horodatage** : ${task.completedAt || new Date().toLocaleString()}
**Durée** : ${res.duration || 'N/A'}

#### 🟢 Éléments Créés :
${createdStr || 'Aucun élément créé.'}

#### 🔵 Éléments Modifiés :
${modifiedStr || 'Aucun élément modifié.'}

#### ⚪ Éléments Ignorés :
${ignoredStr || 'Aucun élément ignoré.'}

#### ⚠️ Avertissements :
${warningsStr || 'Aucun avertissement.'}

#### 🔴 Erreurs / Diagnostic :
${task.errorMessage ? `- ${task.errorMessage}` : 'Aucune erreur détectée.'}

#### 📜 Logs d'Exécution :
\`\`\`
${logsStr}
\`\`\`
`;

    navigator.clipboard.writeText(markdownReport);
    setCopiedTaskId(task.id);
    setTimeout(() => setCopiedTaskId(null), 2500);
  };

  const getEngineBadge = (engine: EngineType) => {
    switch (engine) {
      case 'wordpress':
        return { label: 'WordPress Content', icon: FileText, color: 'text-blue-400 bg-blue-500/10 border-blue-500/30' };
      case 'woocommerce':
        return { label: 'WooCommerce', icon: ShoppingBag, color: 'text-purple-400 bg-purple-500/10 border-purple-500/30' };
      case 'rankmath':
        return { label: 'Rank Math SEO', icon: SearchIcon, color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' };
      case 'audit':
        return { label: 'Audit & Health', icon: Activity, color: 'text-amber-400 bg-amber-500/10 border-amber-500/30' };
      default:
        return { label: engine, icon: Layers, color: 'text-slate-400 bg-slate-500/10 border-slate-500/30' };
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono bg-blue-500/20 text-blue-300 border border-blue-500/30">
              Rapports d'Exécution
            </span>
            <span className="text-xs text-slate-500 font-mono">DigiWare AI Platform</span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight mt-1">
            Résultats & Rapports de Production
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Consultez les détails, créations, modifications, avertissements et liens en direct pour chaque tâche exécutée.
          </p>
        </div>

        {/* Global Summary Badges */}
        <div className="flex items-center space-x-3">
          <div className="bg-slate-900 border border-slate-800 rounded-lg px-3.5 py-2 text-center">
            <span className="text-[10px] text-slate-400 uppercase font-mono block">Rapports</span>
            <span className="text-lg font-bold text-white font-mono">{reportTasks.length}</span>
          </div>
          <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-lg px-3.5 py-2 text-center">
            <span className="text-[10px] text-emerald-400 uppercase font-mono block">Succès</span>
            <span className="text-lg font-bold text-emerald-300 font-mono">{completedCount}</span>
          </div>
          <div className="bg-red-950/40 border border-red-500/30 rounded-lg px-3.5 py-2 text-center">
            <span className="text-[10px] text-red-400 uppercase font-mono block">Erreurs</span>
            <span className="text-lg font-bold text-red-300 font-mono">{errorCount}</span>
          </div>
        </div>
      </div>

      {/* Filter Controls */}
      <div className="flex flex-col md:flex-row gap-3 bg-slate-900 p-3.5 rounded-xl border border-slate-800">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Rechercher une tâche par titre ou mot-clé..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-slate-500 shrink-0" />
          <select
            value={selectedEngine}
            onChange={(e) => setSelectedEngine(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-blue-500 cursor-pointer"
          >
            <option value="all">Tous les Moteurs</option>
            <option value="wordpress">WordPress Content</option>
            <option value="woocommerce">WooCommerce</option>
            <option value="rankmath">Rank Math SEO</option>
            <option value="audit">Audit & Health</option>
          </select>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-blue-500 cursor-pointer"
          >
            <option value="all">Tous les Statuts</option>
            <option value="completed">Terminé (Succès)</option>
            <option value="in_error">Erreur</option>
          </select>
        </div>
      </div>

      {/* Empty State */}
      {filteredTasks.length === 0 && (
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-12 text-center space-y-3">
          <FileCheck2 className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="text-base font-semibold text-slate-300">Aucun rapport d'exécution trouvé</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            {reportTasks.length === 0
              ? "Aucune tâche n'a encore été exécutée par le Queue Manager. Lancez une production depuis l'AI Workspace pour voir les rapports ici."
              : "Aucun résultat ne correspond à vos filtres de recherche actuels."}
          </p>
        </div>
      )}

      {/* Reports List */}
      <div className="space-y-4">
        {filteredTasks.map((task) => {
          const isExpanded = expandedTaskId === task.id;
          const engineInfo = getEngineBadge(task.engine);
          const EngineIcon = engineInfo.icon;
          const res = task.result || {};
          const isCopied = copiedTaskId === task.id;

          return (
            <div
              key={task.id}
              className={`bg-slate-900 rounded-xl border transition-all ${
                task.status === 'in_error'
                  ? 'border-red-500/40 shadow-lg shadow-red-950/20'
                  : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Task Header Bar */}
              <div
                onClick={() => setExpandedTaskId(isExpanded ? null : task.id)}
                className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 cursor-pointer select-none"
              >
                <div className="flex items-start space-x-3 min-w-0">
                  <div
                    className={`mt-0.5 p-2 rounded-lg border ${engineInfo.color} shrink-0`}
                  >
                    <EngineIcon className="w-4 h-4" />
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center space-x-2">
                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded border ${engineInfo.color}`}
                      >
                        {engineInfo.label}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        ID: {task.id}
                      </span>
                    </div>
                    <h3 className="text-sm font-semibold text-white mt-1 truncate">
                      {task.title}
                    </h3>
                  </div>
                </div>

                {/* Right Metadata & Controls */}
                <div className="flex items-center space-x-3 shrink-0 self-end md:self-center">
                  <div className="text-right">
                    <div className="flex items-center justify-end space-x-1.5">
                      {task.status === 'completed' ? (
                        <span className="inline-flex items-center text-[11px] text-emerald-400 font-medium font-mono">
                          <CheckCircle2 className="w-3.5 h-3.5 mr-1 text-emerald-400" />
                          Terminé
                        </span>
                      ) : (
                        <span className="inline-flex items-center text-[11px] text-red-400 font-medium font-mono">
                          <XCircle className="w-3.5 h-3.5 mr-1 text-red-400" />
                          Erreur
                        </span>
                      )}
                    </div>
                    <div className="flex items-center text-[10px] text-slate-500 font-mono mt-0.5 space-x-2">
                      <span className="inline-flex items-center">
                        <Clock className="w-3 h-3 mr-1" />
                        {res.duration || '2.1s'}
                      </span>
                      <span>•</span>
                      <span>
                        {task.completedAt
                          ? new Date(task.completedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                          : 'Récemment'}
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleCopyReport(task);
                    }}
                    title="Copier le rapport complet (Markdown)"
                    className="p-2 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
                  >
                    {isCopied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>

                  <button
                    type="button"
                    className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors"
                  >
                    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Detailed Report View Body */}
              {isExpanded && (
                <div className="border-t border-slate-800/80 p-5 space-y-5 bg-slate-950/50 rounded-b-xl">
                  {/* Central Brain Decision Chain Display */}
                  <div className="bg-slate-900/90 border border-purple-500/30 rounded-xl p-4 space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <div className="flex items-center space-x-2">
                        <Sparkles className="w-4 h-4 text-purple-400" />
                        <span className="text-xs font-bold text-purple-300 uppercase tracking-wider font-mono">
                          Orchestration Cerveau Central DigiWare AI
                        </span>
                      </div>
                      <span className="text-[10px] bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded font-mono border border-purple-500/30">
                        Décision Validée
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                      <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                        <span className="text-slate-500 text-[10px] block font-mono">Objectif Formulé</span>
                        <p className="text-slate-200 font-medium mt-0.5">{task.title}</p>
                      </div>

                      <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                        <span className="text-slate-500 text-[10px] block font-mono">Moteur Assigné & Livrable</span>
                        <p className="text-purple-300 font-medium mt-0.5">
                          {task.engine.toUpperCase()} — {res.producedOutput?.title ? `[Ressource : ${res.producedOutput.title}]` : 'Exécution Directe REST API'}
                        </p>
                      </div>
                    </div>

                    <div className="text-[11px] font-mono text-slate-400 bg-slate-950 p-2.5 rounded-lg border border-slate-800/80 space-y-1">
                      <div className="text-purple-400 font-bold text-[10px]">SÉQUENCE DU CERVEAU CENTRAL :</div>
                      <div>1. OBSERVE : Contexte site web & état système inspectés</div>
                      <div>2. UNDERSTAND : Intention classée & validation de l'objectif</div>
                      <div>3. CONSTRAINTS : Policy Rules vérifiées (Tone, SEO, Sécurité)</div>
                      <div>4. CONTRACT : Émission du contrat vers {task.engine.toUpperCase()}</div>
                      <div>5. EXECUTION : Exécution garantie et synchronisée</div>
                    </div>
                  </div>

                  {/* Overview Stats Bar */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div className="bg-slate-900 border border-slate-800/80 p-3 rounded-lg">
                      <span className="text-slate-500 text-[10px] block font-mono">
                        Éléments Créés
                      </span>
                      <span className="text-base font-bold text-emerald-400 font-mono mt-0.5 block">
                        {(res.itemsCreated || []).length}
                      </span>
                    </div>

                    <div className="bg-slate-900 border border-slate-800/80 p-3 rounded-lg">
                      <span className="text-slate-500 text-[10px] block font-mono">
                        Éléments Modifiés
                      </span>
                      <span className="text-base font-bold text-blue-400 font-mono mt-0.5 block">
                        {(res.itemsModified || []).length}
                      </span>
                    </div>

                    <div className="bg-slate-900 border border-slate-800/80 p-3 rounded-lg">
                      <span className="text-slate-500 text-[10px] block font-mono">
                        Avertissements
                      </span>
                      <span className="text-base font-bold text-amber-400 font-mono mt-0.5 block">
                        {(res.warnings || []).length}
                      </span>
                    </div>

                    <div className="bg-slate-900 border border-slate-800/80 p-3 rounded-lg">
                      <span className="text-slate-500 text-[10px] block font-mono">
                        Policy Score
                      </span>
                      <span className="text-base font-bold text-indigo-400 font-mono mt-0.5 block">
                        {res.seoScore || 90}/100
                      </span>
                    </div>
                  </div>

                  {/* Created Items Section */}
                  {(res.itemsCreated || []).length > 0 && (
                    <div className="space-y-2">
                      <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider font-mono flex items-center">
                        <CheckCircle2 className="w-3.5 h-3.5 mr-1.5" />
                        Éléments Créés sur WordPress
                      </h4>
                      <div className="space-y-2">
                        {res.itemsCreated.map((item: any, idx: number) => (
                          <div
                            key={idx}
                            className="flex items-center justify-between p-3 bg-emerald-950/20 border border-emerald-500/20 rounded-lg text-xs"
                          >
                            <div>
                              <p className="font-semibold text-slate-200">{item.title}</p>
                              <span className="text-[10px] text-emerald-400 font-mono">
                                Type : {item.type}
                              </span>
                            </div>

                            <a
                              href={item.link}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-center px-2.5 py-1 text-[11px] font-medium text-emerald-300 bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/30 rounded-md transition-colors"
                            >
                              Voir sur le site <ExternalLink className="w-3 h-3 ml-1" />
                            </a>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Modified Items Section */}
                  {(res.itemsModified || []).length > 0 && (
                    <div className="space-y-2">
                      <h4 className="text-xs font-bold text-blue-400 uppercase tracking-wider font-mono flex items-center">
                        <Sparkles className="w-3.5 h-3.5 mr-1.5" />
                        Éléments Modifiés via REST API
                      </h4>
                      <div className="space-y-2">
                        {res.itemsModified.map((item: any, idx: number) => (
                          <div
                            key={idx}
                            className="flex items-center justify-between p-3 bg-blue-950/20 border border-blue-500/20 rounded-lg text-xs"
                          >
                            <div>
                              <p className="font-semibold text-slate-200">{item.title}</p>
                              <span className="text-[10px] text-blue-400 font-mono">
                                Action : {item.type}
                              </span>
                            </div>

                            <a
                              href={item.link || wpConfig.siteUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-center px-2.5 py-1 text-[11px] font-medium text-blue-300 bg-blue-500/20 hover:bg-blue-500/30 border border-blue-500/30 rounded-md transition-colors"
                            >
                              Consulter <ExternalLink className="w-3 h-3 ml-1" />
                            </a>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Ignored Items Section */}
                  {(res.itemsIgnored || []).length > 0 && (
                    <div className="space-y-2">
                      <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">
                        Éléments Ignorés
                      </h4>
                      <div className="space-y-2">
                        {res.itemsIgnored.map((item: any, idx: number) => (
                          <div
                            key={idx}
                            className="p-3 bg-slate-900 border border-slate-800 rounded-lg text-xs"
                          >
                            <p className="font-semibold text-slate-300">{item.title}</p>
                            <span className="text-[10px] text-slate-500 font-mono">
                              Raison : {item.reason}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Warnings Section */}
                  {(res.warnings || []).length > 0 && (
                    <div className="space-y-2">
                      <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider font-mono flex items-center">
                        <AlertTriangle className="w-3.5 h-3.5 mr-1.5" />
                        Avertissements & Recommandations
                      </h4>
                      <div className="p-3 bg-amber-950/20 border border-amber-500/30 rounded-lg text-xs text-amber-200 space-y-1">
                        {res.warnings.map((w: string, idx: number) => (
                          <p key={idx}>• {w}</p>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Errors Section */}
                  {task.status === 'in_error' && (
                    <div className="space-y-2">
                      <h4 className="text-xs font-bold text-red-400 uppercase tracking-wider font-mono flex items-center">
                        <XCircle className="w-3.5 h-3.5 mr-1.5" />
                        Diagnostic d'Erreur
                      </h4>
                      <div className="p-3 bg-red-950/30 border border-red-500/30 rounded-lg text-xs text-red-200 font-mono">
                        {task.errorMessage || "Échec de connexion REST API avec WordPress."}
                      </div>
                    </div>
                  )}

                  {/* Full Execution Logs Terminal Box */}
                  <div className="space-y-1.5">
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">
                      Logs d'Exécution Complets
                    </h4>
                    <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/80 font-mono text-[11px] text-slate-400 space-y-1 max-h-40 overflow-y-auto">
                      {task.logs.map((log, idx) => (
                        <div key={idx} className="leading-relaxed">
                          {log}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

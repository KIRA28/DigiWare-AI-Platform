import React, { useState } from 'react';
import JSZip from 'jszip';
import { usePlatform } from '../context/PlatformContext';
import {
  Download,
  FileCode,
  FileText,
  CheckCircle2,
  Sparkles,
  Bot,
  PackageCheck,
  ShieldCheck,
  Zap,
  Globe,
  X,
} from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose }) => {
  const { wpConfig, policyRules, queueTasks, projects } = usePlatform();
  const [isGenerating, setIsGenerating] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  if (!isOpen) return null;

  const handleDownloadZip = async () => {
    setIsGenerating(true);
    setDownloadSuccess(false);

    try {
      const zip = new JSZip();

      // 1. Add WordPress Helper Plugin PHP Code
      const pluginBridgeCode = `<?php
/**
 * Plugin Name: DigiWare AI Bridge Helper
 * Plugin URI:  https://digiware.ai
 * Description: Extension Passerelle Officielle pour DigiWare AI Platform V1.0. Active le contrôle bidirectionnel REST API sécurisé pour WordPress, WooCommerce et Rank Math SEO.
 * Version:     1.0.0
 * Author:      DigiWare Informatique
 * Author URI:  https://digiware.ai
 * License:     GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class DigiWare_AI_Bridge {
    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );
    }

    public function register_rest_routes() {
        register_rest_route( 'digiware/v1', '/status', array(
            'methods'  => 'GET',
            'callback' => array( $this, 'get_status' ),
            'permission_callback' => '__return_true',
        ) );

        register_rest_route( 'digiware/v1', '/sync-seo', array(
            'methods'  => 'POST',
            'callback' => array( $this, 'sync_rankmath_seo' ),
            'permission_callback' => array( $this, 'check_permissions' ),
        ) );
    }

    public function get_status() {
        return rest_ensure_response( array(
            'status'          => 'active',
            'version'         => '1.0.0',
            'wordpress'       => get_bloginfo( 'version' ),
            'woocommerce'     => class_exists( 'WooCommerce' ),
            'rank_math'       => class_exists( 'RankMath' ),
            'site_name'       => get_bloginfo( 'name' ),
            'site_url'        => get_site_url(),
            'timestamp'       => current_time( 'mysql' ),
        ) );
    }

    public function sync_rankmath_seo( $request ) {
        $params  = $request->get_json_params();
        $post_id = isset( $params['post_id'] ) ? intval( $params['post_id'] ) : 0;
        if ( ! $post_id ) {
            return new WP_Error( 'invalid_post', 'ID d\\'article invalide', array( 'status' => 400 ) );
        }

        if ( isset( $params['focus_keyword'] ) ) {
            update_post_meta( $post_id, 'rank_math_focus_keyword', sanitize_text_field( $params['focus_keyword'] ) );
        }
        if ( isset( $params['title'] ) ) {
            update_post_meta( $post_id, 'rank_math_title', sanitize_text_field( $params['title'] ) );
        }
        if ( isset( $params['description'] ) ) {
            update_post_meta( $post_id, 'rank_math_description', sanitize_text_field( $params['description'] ) );
        }

        return rest_ensure_response( array(
            'success' => true,
            'post_id' => $post_id,
            'message' => 'Métadonnées Rank Math SEO synchronisées avec succès',
        ) );
    }

    public function check_permissions() {
        return current_user_can( 'edit_posts' );
    }
}

new DigiWare_AI_Bridge();
`;
      zip.file('wordpress-plugin/digiware-ai-bridge.php', pluginBridgeCode);

      // 2. Add Readme instructions for another AI
      const aiInstructionText = `# DOCUMENTATION D'ANALYSE POUR AUTRE IA — DIGIWARE AI PLATFORM V1.0

Ce fichier est destiné à être transmis à une autre Intelligence Artificielle (ChatGPT, Claude, Gemini, DeepSeek, etc.) pour analyse, audit, ou continuation du développement.

---

## 1. VUE D'ENSEMBLE DE LA PLATEFORME

DigiWare AI Platform V1.0 est un Système d'Exploitation complet et intelligent conçu pour orchestrer la gestion globale d'un site WordPress et e-commerce WooCommerce.

La plateforme repose sur :
- **Un Cerveau Décisionnel (AI Workspace)** : Transforme les objectifs utilisateur en stratégies structurées.
- **Un Gardien Stratégique (Policy Engine)** : Garantit qu'aucune décision ne dérive en appliquant des règles strictes (SEO, Ton, Contraintes métier).
- **Un Garant de l'Exécution (Queue Manager)** : Gère la file d'attente résiliente, les points de contrôle et les reprises.
- **Un Gestionnaire du Temps (Scheduler)** : Équilibre la charge, les quotas API et la planification globale.
- **5 Moteurs Spécialisés** :
  1. WordPress Content Engine (Articles, Pages, Catégories)
  2. WooCommerce Catalog Engine (Fiches produits, Attributs, Stocks)
  3. Rank Math SEO Engine (Mots-clés cibles, Meta Titles/Descriptions, Schema FAQ)
  4. Site Audit & Health Engine (Santé technique, Performance, Sécurité)
  5. Media Engine (Optimisation visuels & Alt tags)
- **Gestionnaire de Ressources IA (AI Resource Manager)** : Inventaire dynamique des capacités/quotas des modèles.
- **Mémoire Globale & Boucle d'Amélioration Continue** : Apprentissage autonome basé sur les résultats mesurés.

---

## 2. CONFIGURATION & CONNEXION REST API WORDPRESS

- **Mode de fonctionnement actuel** : ${wpConfig.mode.toUpperCase()}
- **URL du site cible** : ${wpConfig.siteUrl}
- **Nom d'utilisateur WP** : ${wpConfig.username}
- **Rank Math Actif** : ${wpConfig.rankMathActive ? 'Oui' : 'Non'}
- **WooCommerce Actif** : ${wpConfig.wooActive ? 'Oui' : 'Non'}

---

## 3. RÈGLES ACTIVES DU POLICY ENGINE

${policyRules.filter(r => r.active).map(r => `- [${r.category.toUpperCase()}] ${r.title} : ${r.ruleText}`).join('\n')}

---

## 4. INSTRUCTIONS D'AUDIT POUR L'IA RECEPTRICE

1. Analyse la cohérence entre la mémoire décisionnelle du AI Workspace et les contraintes du Policy Engine.
2. Vérifie la conformité du code PHP de la passerelle \`wordpress-plugin/digiware-ai-bridge.php\` fourni dans ce ZIP.
3. Propose des optimisations pour renforcer la résilience du Queue Manager et du Scheduler.
`;
      zip.file('README_FOR_OTHER_AI.md', aiInstructionText);

      // 3. Add Complete Architectural Specifications Document
      const archDoc = `# SPÉCIFICATIONS ARCHITECTURALES - DIGIWARE AI PLATFORM V4

## PHILOSOPHIE ARCHITECTURALE
DigiWare AI Platform V1.0 est une plateforme d'orchestration décisionnelle et de production pour WordPress/WooCommerce.
Séparation stricte des responsabilités :
- AI Workspace = Décide
- AI Resource Manager = Connaît les ressources et quotas IA
- Policy Engine = Protège la stratégie et les contraintes
- Queue Manager = Garantit la continuité d'exécution sans perte
- Scheduler = Décide du temps et répartit la charge
- Moteurs Métier = Produits autonomes spécialisés

## LISTE DES MODULES ET RESPONSABILITÉS UNIQUES
1. **AI Workspace** : Mémoire décisionnelle vivante du projet.
2. **Policy Engine** : Gardien des règles (SEO Rank Math, WooCommerce, Ton).
3. **Queue Manager** : Gestionnaire de file d'attente résiliente avec checkpoints.
4. **Scheduler** : Ordonnanceur temporel basé sur les priorités et quotas.
5. **AI Resource Manager** : Inventaire des modèles IA et métriques de coût.
6. **Plateform Long-Term Memory** : Base de connaissances globale d'apprentissage.
7. **Continuous Feedback Loop** : Boucle de mesure d'impact et d'auto-amélioration.
8. **WordPress Engine** : Production d'articles et contenus rédigés.
9. **WooCommerce Engine** : Enrichissement du catalogue e-commerce.
10. **Rank Math Engine** : Optimisation des métadonnées et snippets sémantiques.
11. **Site Audit Engine** : Surveillance proactive de la santé technique.
`;
      zip.file('DIGIWARE_ARCHITECTURE_SPECIFICATIONS_V4.md', archDoc);

      // 4. Add Export Config JSON
      const configExport = {
        exportedAt: new Date().toISOString(),
        platformVersion: '1.0.0',
        wpConfig,
        activePolicyRules: policyRules,
        queueSummary: {
          totalTasks: queueTasks.length,
          completed: queueTasks.filter(t => t.status === 'completed').length,
          pending: queueTasks.filter(t => t.status === 'pending').length,
        },
        projects,
      };
      zip.file('digiware-config-export.json', JSON.stringify(configExport, null, 2));

      // Generate the ZIP blob
      const content = await zip.generateAsync({ type: 'blob' });

      // Trigger Browser Download
      const blobUrl = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = `digiware-ai-platform-v1-bundle.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(blobUrl);

      setDownloadSuccess(true);
    } catch (err) {
      console.error('Erreur génération ZIP:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-2xl w-full space-y-6 shadow-2xl relative text-slate-200 text-xs">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg bg-slate-800/50 hover:bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="space-y-1 pr-8">
          <div className="flex items-center space-x-2">
            <span className="bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 text-[10px] font-mono px-2 py-0.5 rounded-full font-semibold">
              Module d'Exportation Intelligente
            </span>
            <span className="text-slate-400 font-mono text-[11px]">Format Archive ZIP</span>
          </div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <PackageCheck className="w-6 h-6 text-cyan-400" />
            <span>Télécharger le Package d'Export (ZIP) pour IA</span>
          </h2>
          <p className="text-slate-400 text-xs leading-relaxed">
            Ce système génère un fichier ZIP complet prêt à être transmis directement à une autre Intelligence Artificielle (Claude, ChatGPT, Gemini, etc.) ou installé sur votre site.
          </p>
        </div>

        {/* Included Package Contents Grid */}
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3 font-mono text-[11px]">
          <h3 className="font-bold text-white uppercase text-[10px] tracking-wider text-slate-400">
            Contenu de l'Archive ZIP Générée :
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-800/80 flex items-start space-x-2.5">
              <FileCode className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <div className="text-white font-semibold">digiware-ai-bridge.php</div>
                <div className="text-[10px] text-slate-500">Plugin Passerelle WordPress officiel</div>
              </div>
            </div>

            <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-800/80 flex items-start space-x-2.5">
              <Bot className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
              <div>
                <div className="text-white font-semibold">README_FOR_OTHER_AI.md</div>
                <div className="text-[10px] text-slate-500">Instructions pour une autre IA</div>
              </div>
            </div>

            <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-800/80 flex items-start space-x-2.5">
              <FileText className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
              <div>
                <div className="text-white font-semibold">DIGIWARE_ARCH_V4.md</div>
                <div className="text-[10px] text-slate-500">Spécifications V1 à V4 complètes</div>
              </div>
            </div>

            <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-800/80 flex items-start space-x-2.5">
              <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <div className="text-white font-semibold">digiware-config-export.json</div>
                <div className="text-[10px] text-slate-500">Règles Policy Engine & Identifiants API</div>
              </div>
            </div>
          </div>
        </div>

        {/* Action Button & Status */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800">
          {downloadSuccess ? (
            <div className="flex items-center space-x-2 text-emerald-400 font-medium">
              <CheckCircle2 className="w-4 h-4" />
              <span>Archive ZIP téléchargée avec succès !</span>
            </div>
          ) : (
            <span className="text-slate-500 text-[11px]">
              Fichier .zip 100% autonome et sécurisé.
            </span>
          )}

          <div className="flex items-center space-x-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs cursor-pointer"
            >
              Fermer
            </button>

            <button
              onClick={handleDownloadZip}
              disabled={isGenerating}
              className="flex items-center space-x-2 bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-semibold px-5 py-2.5 rounded-xl shadow-lg transition-all text-xs cursor-pointer disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              <span>{isGenerating ? 'Génération du ZIP...' : 'Télécharger le ZIP Maintenant'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { usePlatform } from '../context/PlatformContext';
import { PolicyRule } from '../types';
import {
  ShieldCheck,
  Plus,
  Trash2,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Play,
  FileCheck,
  Tag,
  Sparkles,
  BookOpen,
} from 'lucide-react';

export const PolicyEngineView: React.FC = () => {
  const { policyRules, togglePolicyRule, addPolicyRule, deletePolicyRule } = usePlatform();

  const [showAddRuleModal, setShowAddRuleModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<PolicyRule['category']>('tone');
  const [newRuleText, setNewRuleText] = useState('');

  // Policy Auditor Test State
  const [testText, setTestText] = useState('');
  const [auditResult, setAuditResult] = useState<{
    compliant: boolean;
    score: number;
    issues: string[];
  } | null>(null);
  const [isAuditing, setIsAuditing] = useState(false);

  const handleCreateRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newRuleText.trim()) return;

    addPolicyRule({
      title: newTitle,
      category: newCategory,
      ruleText: newRuleText,
      active: true,
    });

    setNewTitle('');
    setNewRuleText('');
    setShowAddRuleModal(false);
  };

  const handleRunAuditTest = async () => {
    if (!testText.trim()) return;
    setIsAuditing(true);

    try {
      const activeRules = policyRules.filter((r) => r.active);
      const res = await fetch('/api/ai/check-policy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: testText, rules: activeRules }),
      });
      const data = await res.json();
      setAuditResult(data);
    } catch (e) {
      console.error('Audit Error:', e);
    } finally {
      setIsAuditing(false);
    }
  };

  const categoryLabels: Record<PolicyRule['category'], string> = {
    tone: 'Ton Rédactionnel',
    seo: 'Structure SEO',
    woocommerce: 'Règles WooCommerce',
    constraint: 'Contrainte Technique',
    exclusion: 'Mots-Clés Exclus',
    digiware: 'Charte DigiWare',
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto text-slate-200">
      {/* Title Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="bg-amber-500/10 text-amber-400 border border-amber-500/20 text-xs font-mono px-2.5 py-0.5 rounded-full font-semibold">
              Garde-Fou d'Alignement Stratégique
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Injections Multi-Modèles
            </span>
          </div>
          <h1 className="text-2xl font-bold text-white flex items-center space-x-2">
            <ShieldCheck className="w-6 h-6 text-amber-400" />
            <span>Policy Engine (Gardien de la Stratégie)</span>
          </h1>
          <p className="text-xs text-slate-400 max-w-2xl">
            Le Policy Engine garantit qu'aucun contenu généré ne dévie des décisions stratégiques convenues avec l'utilisateur (ton d'expert, structure SEO Rank Math, prix minimums, exclusions concurrentielles).
          </p>
        </div>

        <button
          onClick={() => setShowAddRuleModal(true)}
          className="flex items-center space-x-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-semibold px-4 py-2.5 rounded-xl shadow-lg transition-all text-xs cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Créer une Règle</span>
        </button>
      </div>

      {/* Rules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {policyRules.map((rule) => (
          <div
            key={rule.id}
            className={`p-4 rounded-xl border transition-all space-y-3 relative ${
              rule.active
                ? 'bg-slate-900 border-amber-500/30 shadow-md'
                : 'bg-slate-900/50 border-slate-800 opacity-60'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono uppercase bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                {categoryLabels[rule.category]}
              </span>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => togglePolicyRule(rule.id)}
                  className={`text-[10px] font-mono px-2 py-0.5 rounded border font-semibold cursor-pointer ${
                    rule.active
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                >
                  {rule.active ? 'Activité: OUI' : 'Désactivée'}
                </button>

                <button
                  onClick={() => deletePolicyRule(rule.id)}
                  className="text-slate-500 hover:text-red-400 text-xs transition-colors cursor-pointer"
                  title="Supprimer la règle"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <h3 className="text-sm font-bold text-white">{rule.title}</h3>

            <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-lg border border-slate-850 font-mono text-[11px]">
              {rule.ruleText}
            </p>

            <div className="text-[10px] text-slate-500 font-mono text-right">
              Créée le {rule.createdAt}
            </div>
          </div>
        ))}
      </div>

      {/* Interactive Policy Audit Tester */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
        <div className="flex items-center space-x-2">
          <FileCheck className="w-5 h-5 text-amber-400" />
          <h2 className="text-base font-bold text-white">Auditeur de Conformité en Temps Réel</h2>
        </div>
        <p className="text-xs text-slate-400">
          Collez un extrait de texte ou une proposition d'article pour évaluer immédiatement sa conformité vis-à-vis des règles actives du Policy Engine.
        </p>

        <div className="space-y-3">
          <textarea
            value={testText}
            onChange={(e) => setTestText(e.target.value)}
            placeholder="Saisissez un texte à tester (ex : 'Achetez notre vélo incroyable et super-révolutionnaire pour booster vos sorties...')..."
            rows={3}
            className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 text-xs text-white p-3 rounded-xl focus:outline-none resize-none font-mono"
          />

          <div className="flex justify-end">
            <button
              onClick={handleRunAuditTest}
              disabled={!testText.trim() || isAuditing}
              className="flex items-center space-x-2 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold px-4 py-2 rounded-xl transition-all shadow-md cursor-pointer disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isAuditing ? 'Analyse en cours...' : 'Tester la Conformité'}</span>
            </button>
          </div>
        </div>

        {/* Audit Test Results */}
        {auditResult && (
          <div className="mt-4 p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center space-x-2">
                {auditResult.compliant ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                ) : (
                  <XCircle className="w-4 h-4 text-red-400" />
                )}
                <span>Résultat d'Analyse Policy Engine</span>
              </span>
              <span className="text-xs font-mono font-bold text-emerald-400">
                Score: {auditResult.score}/100
              </span>
            </div>

            {auditResult.issues && auditResult.issues.length > 0 ? (
              <ul className="text-xs text-slate-300 space-y-1 list-disc pl-5">
                {auditResult.issues.map((iss, i) => (
                  <li key={i}>{iss}</li>
                ))}
              </ul>
            ) : (
              <p className="text-xs text-emerald-400">
                Le contenu respecte à 100% l'ensemble des directives et de la charte DigiWare.
              </p>
            )}
          </div>
        )}
      </div>

      {/* Modal Add Rule */}
      {showAddRuleModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <ShieldCheck className="w-5 h-5 text-amber-400" />
                <span>Ajouter une Directive Stratégique</span>
              </h3>
              <button
                onClick={() => setShowAddRuleModal(false)}
                className="text-slate-400 hover:text-white font-bold text-xs"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateRule} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Titre de la Règle</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="ex: Ton Expert & Factuel"
                  className="w-full bg-slate-950 border border-slate-800 text-white p-2.5 rounded-lg focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Catégorie</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 text-white p-2.5 rounded-lg focus:outline-none"
                >
                  <option value="tone">Ton Rédactionnel</option>
                  <option value="seo">Structure SEO</option>
                  <option value="woocommerce">Règles WooCommerce</option>
                  <option value="constraint">Contrainte Technique</option>
                  <option value="exclusion">Mots-Clés Exclus</option>
                  <option value="digiware">Charte DigiWare</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Énoncé Strict de la Règle</label>
                <textarea
                  value={newRuleText}
                  onChange={(e) => setNewRuleText(e.target.value)}
                  placeholder="Consigne détaillée transmise aux modèles IA lors de l'exécution..."
                  rows={3}
                  className="w-full bg-slate-950 border border-slate-800 text-white p-2.5 rounded-lg focus:outline-none resize-none"
                  required
                />
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowAddRuleModal(false)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold cursor-pointer"
                >
                  Enregistrer la Règle
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

import React from 'react';
import { usePlatform } from '../context/PlatformContext';
import {
  Brain,
  Layers,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Sparkles,
  TrendingUp,
  Activity,
  FileText,
  ShoppingBag,
  ArrowRight,
  Database,
  RefreshCw,
} from 'lucide-react';

export const DashboardView: React.FC = () => {
  const {
    projects,
    conversations,
    queueTasks,
    policyRules,
    siteAudit,
    systemQuota,
    setActiveTab,
    wpPosts,
    wooProducts,
  } = usePlatform();

  const pendingTasks = queueTasks.filter((t) => t.status === 'pending');
  const inProgressTasks = queueTasks.filter((t) => t.status === 'in_progress');
  const completedTasks = queueTasks.filter((t) => t.status === 'completed');
  const suspendedTasks = queueTasks.filter((t) => t.status === 'suspended');
  const errorTasks = queueTasks.filter((t) => t.status === 'in_error');

  const activeRules = policyRules.filter((r) => r.active);
  const tokenPercentage = Math.round((systemQuota.geminiTokensUsed / systemQuota.geminiDailyLimit) * 100);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner & Quick Orientation */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <span className="bg-blue-500/10 text-blue-400 border border-blue-500/20 text-xs font-mono px-2.5 py-0.5 rounded-full font-semibold">
                Centre de Contrôle Global
              </span>
              <span className="text-slate-400 text-xs font-mono">
                {new Date().toLocaleDateString('fr-FR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              DigiWare AI Platform V1.0
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Votre système d'exploitation intelligent supervise l'ensemble de vos opérations WordPress, WooCommerce et Rank Math. Exprimez vos objectifs, l'intelligence centrale orchestre la production.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              onClick={() => setActiveTab('workspace')}
              className="flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold px-4 py-2.5 rounded-xl shadow-lg shadow-blue-600/25 transition-all text-xs cursor-pointer"
            >
              <Brain className="w-4 h-4" />
              <span>Ouvrir AI Workspace</span>
            </button>
            <button
              onClick={() => setActiveTab('queue')}
              className="flex items-center space-x-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold px-4 py-2.5 rounded-xl transition-all text-xs cursor-pointer"
            >
              <Layers className="w-4 h-4 text-cyan-400" />
              <span>Superviser la File ({pendingTasks.length + inProgressTasks.length})</span>
            </button>
          </div>
        </div>
      </div>

      {/* Primary KPI Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Active Projects */}
        <div
          onClick={() => setActiveTab('workspace')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-4 transition-all cursor-pointer group shadow-sm hover:shadow-md"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-400">Projets & Stratégies</span>
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
              <Brain className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white">{projects.length}</span>
            <span className="text-xs text-slate-400">{conversations.length} conversations</span>
          </div>
          <div className="mt-2 text-[11px] text-blue-400 font-medium flex items-center">
            <span>Explorer le cerveau</span>
            <ArrowRight className="w-3 h-3 ml-1 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Queue Status */}
        <div
          onClick={() => setActiveTab('queue')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-4 transition-all cursor-pointer group shadow-sm hover:shadow-md"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-400">Tâches en Cours / Attente</span>
            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white">
              {pendingTasks.length + inProgressTasks.length}
            </span>
            <span className="text-xs text-emerald-400 font-medium">
              {completedTasks.length} terminées
            </span>
          </div>
          <div className="mt-2 text-[11px] text-cyan-400 font-medium flex items-center">
            <span>Gérer la file d'exécution</span>
            <ArrowRight className="w-3 h-3 ml-1 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Policy Engine Rules */}
        <div
          onClick={() => setActiveTab('policy')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-4 transition-all cursor-pointer group shadow-sm hover:shadow-md"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-400">Règles Policy Engine</span>
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white">{activeRules.length}</span>
            <span className="text-xs text-slate-400">100% conformité</span>
          </div>
          <div className="mt-2 text-[11px] text-amber-400 font-medium flex items-center">
            <span>Ajuster les directives</span>
            <ArrowRight className="w-3 h-3 ml-1 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Health Score */}
        <div
          onClick={() => setActiveTab('audit')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-4 transition-all cursor-pointer group shadow-sm hover:shadow-md"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-400">Santé du Site WP & Woo</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
              <Activity className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-emerald-400">{siteAudit.overallScore}%</span>
            <span className="text-xs text-slate-400">{siteAudit.issues.length} alertes</span>
          </div>
          <div className="mt-2 text-[11px] text-emerald-400 font-medium flex items-center">
            <span>Lancer un diagnostic</span>
            <ArrowRight className="w-3 h-3 ml-1 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>
      </div>

      {/* Quota & AI Models Status + Engine Summaries */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quota & AI Resource Gauge */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span>Consommation Modèles IA</span>
            </h3>
            <span className="text-xs text-indigo-300 font-mono bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
              Gemini 3.6 Flash
            </span>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Tokens Quotidien Utilisés</span>
              <span className="text-white font-mono font-medium">
                {systemQuota.geminiTokensUsed.toLocaleString('fr-FR')} / {systemQuota.geminiDailyLimit.toLocaleString('fr-FR')}
              </span>
            </div>
            <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-blue-500 to-indigo-500 h-full transition-all duration-500"
                style={{ width: `${Math.min(100, tokenPercentage)}%` }}
              ></div>
            </div>
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>0%</span>
              <span>{tokenPercentage}% de la capacité quotidienne</span>
              <span>100%</span>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-800 grid grid-cols-2 gap-2 text-xs">
            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <span className="text-slate-500 block text-[10px]">Requêtes WP API</span>
              <span className="text-slate-200 font-mono font-semibold">{systemQuota.wpApiRequests} ops</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <span className="text-slate-500 block text-[10px]">Requêtes WooCommerce</span>
              <span className="text-slate-200 font-mono font-semibold">{systemQuota.wooApiRequests} ops</span>
            </div>
          </div>
        </div>

        {/* Engine Production States */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 lg:col-span-2">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white flex items-center space-x-2">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
              <span>État des Moteurs de Production</span>
            </h3>
            <span className="text-xs text-slate-400">Catalogue Sync</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* WordPress Content */}
            <div
              onClick={() => setActiveTab('wordpress')}
              className="bg-slate-950 border border-slate-800 hover:border-slate-700 p-3.5 rounded-xl cursor-pointer transition-colors space-y-2"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <FileText className="w-4 h-4 text-blue-400" />
                  <span className="text-xs font-semibold text-slate-200">WordPress</span>
                </div>
                <span className="text-[10px] bg-blue-500/10 text-blue-400 px-1.5 py-0.5 rounded font-mono">
                  {wpPosts.length} articles
                </span>
              </div>
              <p className="text-[11px] text-slate-400 line-clamp-2">
                {wpPosts[0]?.title || 'Aucun article rédigé'}
              </p>
            </div>

            {/* WooCommerce */}
            <div
              onClick={() => setActiveTab('woocommerce')}
              className="bg-slate-950 border border-slate-800 hover:border-slate-700 p-3.5 rounded-xl cursor-pointer transition-colors space-y-2"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <ShoppingBag className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-semibold text-slate-200">WooCommerce</span>
                </div>
                <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-1.5 py-0.5 rounded font-mono">
                  {wooProducts.length} fiches
                </span>
              </div>
              <p className="text-[11px] text-slate-400 line-clamp-2">
                {wooProducts[0]?.name || 'Aucun produit dans le catalogue'}
              </p>
            </div>

            {/* Rank Math SEO */}
            <div
              onClick={() => setActiveTab('rankmath')}
              className="bg-slate-950 border border-slate-800 hover:border-slate-700 p-3.5 rounded-xl cursor-pointer transition-colors space-y-2"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <TrendingUp className="w-4 h-4 text-purple-400" />
                  <span className="text-xs font-semibold text-slate-200">Rank Math SEO</span>
                </div>
                <span className="text-[10px] bg-purple-500/10 text-purple-400 px-1.5 py-0.5 rounded font-mono">
                  Score Moyen 86
                </span>
              </div>
              <p className="text-[11px] text-slate-400 line-clamp-2">
                Méta-balises, Snippet Google, FAQ Schema actifs.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Live Activity Stream & Active Queue Items */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white flex items-center space-x-2">
            <Activity className="w-4 h-4 text-cyan-400" />
            <span>Historique Récent des Opérations (Queue Stream)</span>
          </h3>
          <button
            onClick={() => setActiveTab('queue')}
            className="text-xs text-blue-400 hover:text-blue-300 font-medium flex items-center"
          >
            <span>Voir toute la file</span>
            <ArrowRight className="w-3 h-3 ml-1" />
          </button>
        </div>

        <div className="divide-y divide-slate-800/80">
          {queueTasks.slice(0, 5).map((task) => (
            <div key={task.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
              <div className="flex items-start space-x-3">
                <div className="mt-0.5">
                  {task.status === 'completed' && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
                  {task.status === 'in_progress' && <RefreshCw className="w-4 h-4 text-cyan-400 animate-spin shrink-0" />}
                  {task.status === 'pending' && <Clock className="w-4 h-4 text-slate-400 shrink-0" />}
                  {task.status === 'suspended' && <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />}
                  {task.status === 'in_error' && <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />}
                </div>

                <div>
                  <h4 className="text-slate-200 font-medium">{task.title}</h4>
                  <p className="text-slate-400 text-[11px] line-clamp-1 mt-0.5">
                    {task.logs[task.logs.length - 1] || 'Traitement en attente'}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-2 shrink-0 self-end sm:self-auto font-mono text-[10px]">
                <span className="uppercase bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                  {task.engine}
                </span>
                <span
                  className={`px-2 py-0.5 rounded border capitalize ${
                    task.status === 'completed'
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                      : task.status === 'in_progress'
                      ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20'
                      : task.status === 'suspended'
                      ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                >
                  {task.status === 'completed'
                    ? 'Terminé'
                    : task.status === 'in_progress'
                    ? 'En cours'
                    : task.status === 'suspended'
                    ? 'Suspendu'
                    : 'En attente'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

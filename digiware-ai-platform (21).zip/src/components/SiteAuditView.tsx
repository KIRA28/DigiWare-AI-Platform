import React, { useState } from 'react';
import { usePlatform } from '../context/PlatformContext';
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Database,
  RefreshCw,
  Sparkles,
  Zap,
  ShieldCheck,
  Wrench,
  Search,
} from 'lucide-react';

export const SiteAuditView: React.FC = () => {
  const { siteAudit, autoFixIssue, addTasksToQueue, setActiveTab } = usePlatform();

  const [isScanning, setIsScanning] = useState(false);

  const handleRunFullScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      addTasksToQueue([
        {
          title: 'Scan Complet Santé WordPress & BDD WooCommerce',
          engine: 'audit',
          status: 'completed',
          priority: 'medium',
          payload: { scanDate: new Date().toISOString() },
        },
      ]);
    }, 1500);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto text-slate-200">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-mono px-2.5 py-0.5 rounded-full font-semibold">
              Supervision Technique & BDD
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Nettoyage Auto-Fix
            </span>
          </div>
          <h1 className="text-2xl font-bold text-white flex items-center space-x-2">
            <Activity className="w-6 h-6 text-emerald-400" />
            <span>Site Audit & Health Engine</span>
          </h1>
          <p className="text-xs text-slate-400 max-w-2xl">
            Supervisez la santé technique globale de votre installation WordPress et WooCommerce : nettoyage de la base de données, détection des liens cassés et résolution en 1 clic.
          </p>
        </div>

        <button
          onClick={handleRunFullScan}
          disabled={isScanning}
          className="flex items-center space-x-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-semibold px-4 py-2.5 rounded-xl shadow-lg transition-all text-xs cursor-pointer shrink-0 disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${isScanning ? 'animate-spin' : ''}`} />
          <span>{isScanning ? 'Analyse en cours...' : 'Lancer l\'Audit Complet'}</span>
        </button>
      </div>

      {/* Health Metric Score Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <span className="text-[10px] text-slate-400 font-mono uppercase">Score SEO Global</span>
          <div className="text-2xl font-bold text-emerald-400 font-mono">{siteAudit.seoScore}%</div>
          <p className="text-[10px] text-slate-500">Méta-balises & Sitemaps</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <span className="text-[10px] text-slate-400 font-mono uppercase">Performance & Vitesse</span>
          <div className="text-2xl font-bold text-cyan-400 font-mono">{siteAudit.performanceScore}%</div>
          <p className="text-[10px] text-slate-500">Transients & WebP</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <span className="text-[10px] text-slate-400 font-mono uppercase">Santé WooCommerce</span>
          <div className="text-2xl font-bold text-purple-400 font-mono">{siteAudit.wooHealthScore}%</div>
          <p className="text-[10px] text-slate-500">Tables wp_options & Stock</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <span className="text-[10px] text-slate-400 font-mono uppercase">Sécurité & Core WP</span>
          <div className="text-2xl font-bold text-amber-400 font-mono">{siteAudit.securityScore}%</div>
          <p className="text-[10px] text-slate-500">Extensions & Passwords</p>
        </div>
      </div>

      {/* Detected Issues List */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-sm font-semibold text-white flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span>Alertes & Anomalies Détectées ({siteAudit.issues.length})</span>
          </h3>
          <span className="text-xs text-slate-400 font-mono">Dernier audit: {siteAudit.lastAuditDate}</span>
        </div>

        <div className="space-y-3">
          {siteAudit.issues.length === 0 ? (
            <div className="p-8 text-center text-emerald-400 font-medium text-xs flex flex-col items-center justify-center space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-400" />
              <span>Aucune anomalie détectée ! Votre site WordPress est parfaitement optimisé.</span>
            </div>
          ) : (
            siteAudit.issues.map((issue) => (
              <div
                key={issue.id}
                className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span
                      className={`text-[9px] uppercase font-mono px-2 py-0.5 rounded font-bold ${
                        issue.severity === 'critical'
                          ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                          : issue.severity === 'warning'
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                      }`}
                    >
                      {issue.severity}
                    </span>
                    <span className="text-[10px] font-mono bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded">
                      {issue.category}
                    </span>
                    <h4 className="font-semibold text-white">{issue.title}</h4>
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed">{issue.recommendation}</p>
                </div>

                {issue.autoFixable && (
                  <button
                    onClick={() => autoFixIssue(issue.id)}
                    className="flex items-center space-x-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-semibold px-3 py-1.5 rounded-lg text-xs shadow cursor-pointer shrink-0"
                  >
                    <Wrench className="w-3.5 h-3.5" />
                    <span>Auto-Fix (1-Clic)</span>
                  </button>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { usePlatform } from '../context/PlatformContext';
import {
  Settings,
  Globe,
  Key,
  ShieldCheck,
  CheckCircle2,
  RefreshCw,
  Server,
  Zap,
  AlertCircle,
  Download,
  Trash2,
} from 'lucide-react';

export const WPSettingsView: React.FC = () => {
  const { wpConfig, updateWPConfig, clearAllSampleData } = usePlatform();
  const [clearedNotice, setClearedNotice] = useState(false);

  const handlePurgeDemoData = () => {
    if (window.confirm('Voulez-vous supprimer toutes les données de test (articles, fiches produits et file de test) pour commencer avec une interface 100% propre ?')) {
      clearAllSampleData();
      setClearedNotice(true);
      setTimeout(() => setClearedNotice(false), 4000);
    }
  };

  const [siteUrl, setSiteUrl] = useState(wpConfig.siteUrl);
  const [username, setUsername] = useState(wpConfig.username);
  const [appPassword, setAppPassword] = useState(wpConfig.appPassword || '');
  const [mode, setMode] = useState<'simulation' | 'live'>(wpConfig.mode);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Live Test Connection States
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);

  // Diagnostic Mode States
  const [isDiagnosing, setIsDiagnosing] = useState(false);
  const [diagnosticData, setDiagnosticData] = useState<any>(null);

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);

    try {
      const res = await fetch('/api/wp/test-connection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ siteUrl, username, appPassword }),
      });

      const data = await res.json();
      setTestResult(data);

      if (data.success) {
        updateWPConfig({
          siteUrl,
          username,
          appPassword,
          mode: 'live',
          isConnected: true,
          rankMathActive: data.rankMathActive,
          wooActive: data.wooActive,
        });
      }
    } catch (err: any) {
      setTestResult({
        success: false,
        error: `Erreur de communication backend : ${err.message}`,
      });
    } finally {
      setIsTesting(false);
    }
  };

  const handleRunDiagnostic = async () => {
    setIsDiagnosing(true);
    setDiagnosticData(null);

    try {
      const res = await fetch('/api/wp/diagnostic', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ siteUrl, username, appPassword }),
      });
      const data = await res.json();
      setDiagnosticData(data);
    } catch (err: any) {
      setDiagnosticData({
        success: false,
        error: `Erreur lors de l'exécution du diagnostic : ${err.message}`,
      });
    } finally {
      setIsDiagnosing(false);
    }
  };

  const handleDownloadPlugin = () => {
    window.open('/api/wp/bridge-plugin-code', '_blank');
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateWPConfig({
      siteUrl,
      username,
      appPassword,
      mode,
      isConnected: true,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="p-6 space-y-6 max-w-5xl mx-auto text-slate-200">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="bg-blue-500/10 text-blue-400 border border-blue-500/20 text-xs font-mono px-2.5 py-0.5 rounded-full font-semibold">
              Infrastructure Connection REST API
            </span>
            <span className="text-xs text-slate-400 font-mono">
              WordPress Core & WooCommerce REST API
            </span>
          </div>
          <h1 className="text-2xl font-bold text-white flex items-center space-x-2">
            <Settings className="w-6 h-6 text-blue-400" />
            <span>Paramètres de Connexion WordPress & WooCommerce</span>
          </h1>
          <p className="text-xs text-slate-400 max-w-2xl">
            Configurez vos identifiants pour connecter l'extension DigiWare AI Platform à votre site WordPress réel ou basculez en mode simulation haute fidélité.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            onClick={handlePurgeDemoData}
            className="flex items-center space-x-2 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-300 font-semibold px-3.5 py-2.5 rounded-xl transition-all text-xs cursor-pointer"
            title="Effacer les données de démonstration pour avoir une interface 100% propre"
          >
            <Trash2 className="w-4 h-4 text-red-400" />
            <span>Purger Données de Démo</span>
          </button>

          <button
            onClick={handleDownloadPlugin}
            className="flex items-center space-x-2 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-cyan-300 font-semibold px-4 py-2.5 rounded-xl shadow-lg transition-all text-xs cursor-pointer"
          >
            <Download className="w-4 h-4 text-cyan-400" />
            <span>Télécharger Plugin Passerelle (PHP)</span>
          </button>
        </div>
      </div>

      {clearedNotice && (
        <div className="p-3 bg-red-950/60 border border-red-500/40 text-red-200 rounded-xl text-xs flex items-center justify-between font-mono">
          <span className="flex items-center space-x-2">
            <Trash2 className="w-4 h-4 text-red-400" />
            <span>Toutes les données de test ont été supprimées ! L'interface est désormais 100% propre.</span>
          </span>
          <button onClick={() => setClearedNotice(false)} className="text-red-400 font-bold hover:text-white">✕</button>
        </div>
      )}

      <form onSubmit={handleSave} className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-6 shadow-xl text-xs">
        {/* Mode Selector */}
        <div className="space-y-2">
          <label className="block text-slate-300 font-bold text-sm">Mode de Fonctionnement</label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setMode('simulation')}
              className={`p-4 rounded-xl border text-left cursor-pointer transition-all ${
                mode === 'simulation'
                  ? 'bg-blue-600/20 border-blue-500 text-white font-semibold'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-2 mb-1">
                <Server className="w-4 h-4 text-cyan-400" />
                <span className="text-sm font-bold">Environnement Virtuel Démonstration</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Mode sécurisé autonome pré-chargé avec données de démonstration réelles (Articles, Produits WooCommerce, Scores Rank Math). Idéal pour tester sans impacter un site en production.
              </p>
            </button>

            <button
              type="button"
              onClick={() => setMode('live')}
              className={`p-4 rounded-xl border text-left cursor-pointer transition-all ${
                mode === 'live'
                  ? 'bg-blue-600/20 border-blue-500 text-white font-semibold'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-2 mb-1">
                <Globe className="w-4 h-4 text-emerald-400" />
                <span className="text-sm font-bold">Connexion Directe WordPress REST API</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Connectez directement votre site WordPress distant via la REST API v2 officielle avec Mots de passe d'Application (Application Passwords).
              </p>
            </button>
          </div>
        </div>

        {/* Instructions Panel for Application Password */}
        <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 space-y-2 text-slate-300">
          <div className="font-bold text-cyan-400 flex items-center space-x-1.5 text-xs">
            <Zap className="w-4 h-4" />
            <span>Comment connecter un site WordPress réel en 2 minutes ?</span>
          </div>
          <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-400">
            <li>Connectez-vous au tableau de bord de votre site WordPress (ex: <code className="text-slate-300">https://votre-site.com/wp-admin</code>).</li>
            <li>Allez dans <strong>Utilisateurs &gt; Profil</strong>, faites défiler jusqu'à la section <strong>Mots de passe d'application</strong>.</li>
            <li>Saisissez le nom "DigiWare AI Platform" et cliquez sur <strong>Ajouter un mot de passe d'application</strong>.</li>
            <li>Copiez la clé générée (ex: <code className="text-cyan-300 font-mono">abcd 1234 efgh 5678</code>) et collez-la ci-dessous.</li>
          </ol>
        </div>

        {/* Credentials Form */}
        <div className="space-y-4 pt-4 border-t border-slate-800">
          <h3 className="text-sm font-bold text-white flex items-center space-x-2">
            <Key className="w-4 h-4 text-blue-400" />
            <span>Identifiants API WordPress & WooCommerce</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-slate-300 font-medium mb-1">URL du Site WordPress Distant</label>
              <input
                type="url"
                value={siteUrl}
                onChange={(e) => setSiteUrl(e.target.value)}
                placeholder="https://mon-site-wordpress.com"
                className="w-full bg-slate-950 border border-slate-800 text-white p-2.5 rounded-lg focus:outline-none font-mono"
                required
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Nom d'utilisateur Administrateur WP</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="admin_digiware"
                className="w-full bg-slate-950 border border-slate-800 text-white p-2.5 rounded-lg focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Mot de passe d'Application (Application Password)</label>
              <input
                type="password"
                value={appPassword}
                onChange={(e) => setAppPassword(e.target.value)}
                placeholder="xxxx xxxx xxxx xxxx"
                className="w-full bg-slate-950 border border-slate-800 text-white p-2.5 rounded-lg focus:outline-none font-mono"
              />
            </div>
          </div>

          <div className="pt-2 flex flex-wrap gap-2 justify-start">
            <button
              type="button"
              onClick={handleTestConnection}
              disabled={isTesting}
              className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold px-4 py-2 rounded-xl transition-all shadow-md text-xs cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
              <span>{isTesting ? 'Test REST API en cours...' : 'Tester la Connexion Directe en Temps Réel'}</span>
            </button>

            <button
              type="button"
              onClick={handleRunDiagnostic}
              disabled={isDiagnosing}
              className="flex items-center space-x-2 bg-purple-600 hover:bg-purple-500 text-white font-semibold px-4 py-2 rounded-xl transition-all shadow-md text-xs cursor-pointer disabled:opacity-50"
            >
              <ShieldCheck className={`w-3.5 h-3.5 ${isDiagnosing ? 'animate-spin' : ''}`} />
              <span>{isDiagnosing ? 'Diagnostic REST API en cours...' : 'Mode Diagnostic (Preuve de Connexion Réelle)'}</span>
            </button>
          </div>

          {/* Diagnostic Report Panel */}
          {diagnosticData && (
            <div className="p-4 rounded-xl bg-slate-950 border border-purple-500/40 font-mono text-xs space-y-3 shadow-2xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div className="flex items-center space-x-2">
                  <ShieldCheck className="w-5 h-5 text-purple-400" />
                  <span className="font-bold text-sm text-purple-300">Rapport de Diagnostic de Connexion Réelle</span>
                </div>
                <span className="text-[10px] bg-purple-500/20 text-purple-300 border border-purple-500/30 px-2 py-0.5 rounded-full font-bold">
                  {diagnosticData.overallStatus}
                </span>
              </div>

              <div className="text-[11px] text-emerald-400 bg-emerald-950/30 p-2.5 rounded-lg border border-emerald-500/30">
                ✅ <strong>Preuve Technique de Lecture Directe :</strong> {diagnosticData.proofMessage}
              </div>

              {diagnosticData.tests && (
                <div className="space-y-2 pt-1">
                  <div className="text-slate-400 font-bold text-[11px]">Détails des En-Têtes et Réponses REST API Distantes :</div>
                  <div className="grid grid-cols-1 gap-2">
                    {diagnosticData.tests.map((test: any, idx: number) => (
                      <div key={idx} className="p-2.5 bg-slate-900 rounded-lg border border-slate-800 flex flex-col sm:flex-row justify-between sm:items-center gap-1">
                        <div>
                          <div className="text-slate-200 font-bold">{test.label}</div>
                          <div className="text-[10px] text-slate-500 font-mono">{test.url}</div>
                          {test.sampleItem && (
                            <div className="text-[11px] text-cyan-400 mt-1">Exemple Lu : "{test.sampleItem}"</div>
                          )}
                        </div>

                        <div className="flex items-center space-x-3 text-[11px] shrink-0">
                          <span className={test.ok ? 'text-emerald-400 font-bold' : 'text-red-400 font-bold'}>
                            HTTP {test.status}
                          </span>
                          <span className="text-slate-400">{test.latencyMs}ms</span>
                          {test.xWpTotal !== null && (
                            <span className="bg-slate-800 text-slate-200 px-2 py-0.5 rounded border border-slate-700 font-bold">
                              X-WP-Total: {test.xWpTotal}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Test Results Diagnostics Card */}
          {testResult && (
            <div
              className={`p-4 rounded-xl border font-mono text-xs space-y-2 ${
                testResult.success
                  ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                  : 'bg-red-950/40 border-red-500/40 text-red-300'
              }`}
            >
              <div className="flex items-center space-x-2 font-bold text-sm">
                {testResult.success ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-red-400" />
                )}
                <span>
                  {testResult.success
                    ? `REST API Active — ${testResult.siteName} (${testResult.latencyMs}ms)`
                    : 'Erreur de Connexion REST API'}
                </span>
              </div>

              {testResult.success ? (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] pt-1">
                  <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                    <div className="text-slate-400">Nom du Site</div>
                    <div className="text-white font-bold truncate">{testResult.siteName}</div>
                  </div>
                  <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                    <div className="text-slate-400">Compte Utilisateur</div>
                    <div className="text-white font-bold truncate">
                      {testResult.user ? testResult.user.name : 'Public / Non identifié'}
                    </div>
                  </div>
                  <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                    <div className="text-slate-400">WooCommerce API</div>
                    <div className={testResult.wooActive ? 'text-emerald-400 font-bold' : 'text-slate-400'}>
                      {testResult.wooActive ? 'Actif' : 'Non détecté'}
                    </div>
                  </div>
                  <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                    <div className="text-slate-400">Rank Math SEO</div>
                    <div className={testResult.rankMathActive ? 'text-purple-400 font-bold' : 'text-slate-400'}>
                      {testResult.rankMathActive ? 'Actif' : 'Non détecté'}
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-xs text-red-300">{testResult.error}</p>
              )}
            </div>
          )}
        </div>

        {/* Plugin Integrations */}
        <div className="space-y-3 pt-4 border-t border-slate-800">
          <h3 className="text-sm font-bold text-white flex items-center space-x-2">
            <ShieldCheck className="w-4 h-4 text-purple-400" />
            <span>Extensions Détectées & Actives</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono text-xs">
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
              <div>
                <div className="text-white font-semibold">Rank Math SEO PRO</div>
                <div className="text-[10px] text-slate-500">Méta Snippets & Schema JSON-LD</div>
              </div>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/20">
                Connecté
              </span>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
              <div>
                <div className="text-white font-semibold">WooCommerce Core v9.1</div>
                <div className="text-[10px] text-slate-500">REST API Product Endpoints</div>
              </div>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/20">
                Connecté
              </span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
          {savedSuccess ? (
            <span className="text-emerald-400 font-semibold flex items-center space-x-1.5 text-xs">
              <CheckCircle2 className="w-4 h-4" />
              <span>Paramètres de connexion enregistrés et validés !</span>
            </span>
          ) : (
            <span className="text-slate-500 text-[11px]">
              Toutes les connexions sont chiffrées en TLS v1.3.
            </span>
          )}

          <button
            type="submit"
            className="bg-blue-600 hover:bg-blue-500 text-white font-semibold px-5 py-2.5 rounded-xl transition-all shadow-md text-xs cursor-pointer"
          >
            Enregistrer la Configuration
          </button>
        </div>
      </form>
    </div>
  );
};


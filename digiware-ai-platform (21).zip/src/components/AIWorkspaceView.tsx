import React, { useState } from 'react';
import { usePlatform } from '../context/PlatformContext';
import {
  Brain,
  Send,
  Plus,
  Folder,
  Layers,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  Clock,
  ChevronRight,
  MessageSquare,
  ArrowRight,
  Bot,
  User,
  Loader2,
  Mic,
  MicOff,
  Copy,
  Check,
  Download,
  FileText,
} from 'lucide-react';

export const AIWorkspaceView: React.FC = () => {
  const {
    conversations,
    currentConversationId,
    setCurrentConversationId,
    projects,
    createProject,
    sendMessage,
    isAiThinking,
    addTasksToQueue,
    setActiveTab,
    addPolicyRule,
  } = usePlatform();

  const [inputGoal, setInputGoal] = useState('');
  const [selectedProjectId, setSelectedProjectId] = useState<string>('');
  const [showNewProjModal, setShowNewProjModal] = useState(false);
  const [newProjName, setNewProjName] = useState('');
  const [newProjDesc, setNewProjDesc] = useState('');

  const [isListening, setIsListening] = useState(false);
  const [speechError, setSpeechError] = useState<string | null>(null);

  const toggleVoiceRecognition = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setSpeechError("La reconnaissance vocale n'est pas supportée par votre navigateur (utilisez Chrome, Edge ou Safari).");
      setTimeout(() => setSpeechError(null), 5000);
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'fr-FR';
      recognition.continuous = false;
      recognition.interimResults = true;

      recognition.onstart = () => {
        setIsListening(true);
        setSpeechError(null);
      };

      recognition.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((result: any) => result[0])
          .map((result: any) => result.transcript)
          .join('');
        setInputGoal(transcript);
      };

      recognition.onerror = (event: any) => {
        console.error('Erreur reconnaissance vocale:', event.error);
        setIsListening(false);
        if (event.error !== 'no-speech') {
          setSpeechError(`Erreur micro : ${event.error}`);
          setTimeout(() => setSpeechError(null), 5000);
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch (err: any) {
      console.error(err);
      setIsListening(false);
    }
  };

  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const [copiedChat, setCopiedChat] = useState(false);

  const handleCopyMessage = (msgId: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMsgId(msgId);
    setTimeout(() => setCopiedMsgId(null), 2000);
  };

  const currentConv = conversations.find((c) => c.id === currentConversationId) || conversations[0];

  const formatFullChatText = () => {
    if (!currentConv || !currentConv.messages || currentConv.messages.length === 0) return '';
    return currentConv.messages
      .map((m) => {
        const senderLabel = m.sender === 'user' ? 'Utilisateur' : 'DigiWare AI';
        const timestamp = m.timestamp ? ` [${m.timestamp}]` : '';
        let str = `--- ${senderLabel}${timestamp} ---\n${m.text}`;
        if (m.strategy) {
          str += `\n\n[PLAN STRATÉGIQUE: ${m.strategy.summary}]\n`;
          m.strategy.steps.forEach((s: any, i: number) => {
            str += `\nÉtape ${i + 1} (${s.engine}): ${s.title}\nDescription: ${s.description}`;
          });
        }
        return str;
      })
      .join('\n\n========================================\n\n');
  };

  const handleCopyFullChat = () => {
    const fullText = formatFullChatText();
    if (!fullText) return;
    navigator.clipboard.writeText(fullText);
    setCopiedChat(true);
    setTimeout(() => setCopiedChat(false), 2000);
  };

  const handleExportChatFile = () => {
    const fullText = formatFullChatText();
    if (!fullText) return;
    const blob = new Blob([fullText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const fileName = (currentConv?.title || 'discussion-digiware')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
    link.download = `${fileName || 'discussion'}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputGoal.trim() || isAiThinking) return;

    const goal = inputGoal;
    setInputGoal('');
    await sendMessage(goal, selectedProjectId || currentConv?.projectId);
  };

  const handleCreateProjectSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjName.trim()) return;
    createProject(newProjName, newProjDesc, '#3b82f6');
    setNewProjName('');
    setNewProjDesc('');
    setShowNewProjModal(false);
  };

  const handleSendStrategyToQueue = (strategy: any) => {
    if (!strategy || !strategy.steps) return;

    const queueItems = strategy.steps.map((step: any) => ({
      title: step.title,
      engine: step.engine,
      status: 'pending' as const,
      priority: 'high' as const,
      payload: step.payload || {},
    }));

    addTasksToQueue(queueItems);
    setActiveTab('queue');
  };

  return (
    <div className="h-[calc(100vh-65px)] flex flex-col md:flex-row overflow-hidden bg-slate-950 text-slate-200">
      {/* Sidebar: Projects & Conversation Threads */}
      <div className="w-full md:w-80 bg-slate-900/90 border-r border-slate-800 flex flex-col shrink-0">
        {/* Header & New Conversation */}
        <div className="p-4 border-b border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center space-x-1.5 font-mono">
              <Brain className="w-4 h-4 text-cyan-400" />
              <span>Cerveau Central (Workspace)</span>
            </h2>
            <button
              onClick={() => setShowNewProjModal(true)}
              className="text-[11px] text-blue-400 hover:text-blue-300 font-medium flex items-center space-x-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Projet</span>
            </button>
          </div>

          <button
            onClick={() => {
              setCurrentConversationId('');
            }}
            className="w-full flex items-center justify-center space-x-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-semibold px-3 py-2 rounded-xl transition-all shadow-md shadow-blue-600/20 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Nouvel Objectif Stratégique</span>
          </button>
        </div>

        {/* Project Folders & Conversations List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-4">
          {/* Projects Folder Accordion */}
          <div className="space-y-2">
            <h3 className="text-[10px] font-mono font-semibold text-slate-500 uppercase px-2">
              Dossiers Projets ({projects.length})
            </h3>
            <div className="space-y-1">
              {projects.map((proj) => {
                const projConvs = conversations.filter((c) => c.projectId === proj.id);
                return (
                  <div key={proj.id} className="space-y-1">
                    <div className="flex items-center space-x-2 px-2 py-1.5 rounded-lg text-xs font-medium text-slate-300 bg-slate-800/40 border border-slate-800">
                      <Folder className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                      <span className="truncate flex-1 font-semibold">{proj.name}</span>
                      <span className="text-[10px] font-mono text-slate-500 px-1.5 py-0.5 rounded bg-slate-900">
                        {projConvs.length}
                      </span>
                    </div>

                    <div className="pl-4 space-y-0.5">
                      {projConvs.map((conv) => (
                        <button
                          key={conv.id}
                          onClick={() => setCurrentConversationId(conv.id)}
                          className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs truncate transition-colors flex items-center justify-between cursor-pointer ${
                            conv.id === currentConversationId
                              ? 'bg-blue-600/20 text-white border border-blue-500/30 font-medium'
                              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                          }`}
                        >
                          <span className="truncate">{conv.title}</span>
                          <ChevronRight className="w-3 h-3 shrink-0 opacity-60" />
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Unassigned Conversations */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <h3 className="text-[10px] font-mono font-semibold text-slate-500 uppercase px-2">
              Conversations Libres
            </h3>
            <div className="space-y-1">
              {conversations
                .filter((c) => !c.projectId)
                .map((conv) => (
                  <button
                    key={conv.id}
                    onClick={() => setCurrentConversationId(conv.id)}
                    className={`w-full text-left px-2.5 py-2 rounded-lg text-xs truncate transition-colors flex items-center space-x-2 cursor-pointer ${
                      conv.id === currentConversationId
                        ? 'bg-blue-600/20 text-white border border-blue-500/30 font-medium'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                    }`}
                  >
                    <MessageSquare className="w-3.5 h-3.5 shrink-0 text-slate-500" />
                    <span className="truncate flex-1">{conv.title}</span>
                  </button>
                ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Conversation Stream */}
      <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-hidden">
        {/* Thread Header */}
        <div className="p-4 border-b border-slate-800 bg-slate-900/40 flex items-center justify-between shrink-0">
          <div>
            <h1 className="text-base font-bold text-white flex items-center space-x-2">
              <Brain className="w-5 h-5 text-indigo-400" />
              <span>{currentConv ? currentConv.title : 'Nouvel Objectif Stratégique'}</span>
            </h1>
            <p className="text-xs text-slate-400">
              Dialogue direct avec le cerveau central DigiWare AI (Moteur Gemini 3.6 Flash)
            </p>
          </div>

          <div className="flex items-center space-x-2">
            {currentConv && currentConv.messages && currentConv.messages.length > 0 && (
              <>
                <button
                  onClick={handleCopyFullChat}
                  title="Copier toute la conversation"
                  className="flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer"
                >
                  {copiedChat ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400 font-medium">Copié !</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-slate-400" />
                      <span className="hidden sm:inline">Copier le chat</span>
                    </>
                  )}
                </button>

                <button
                  onClick={handleExportChatFile}
                  title="Exporter la conversation au format .txt"
                  className="flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="hidden sm:inline">Exporter (.txt)</span>
                </button>
              </>
            )}

            <select
              value={selectedProjectId}
              onChange={(e) => setSelectedProjectId(e.target.value)}
              className="bg-slate-800 border border-slate-700 text-xs text-slate-300 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-blue-500"
            >
              <option value="">-- Ranger dans un projet --</option>
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Message Log */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          {!currentConv || currentConv.messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center max-w-xl mx-auto space-y-4 text-slate-400">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600/20 via-indigo-600/20 to-cyan-500/20 border border-slate-800 flex items-center justify-center">
                <Brain className="w-8 h-8 text-cyan-400" />
              </div>
              <h2 className="text-lg font-bold text-white">Quel est votre objectif aujourd'hui ?</h2>
              <p className="text-xs text-slate-400 leading-relaxed">
                Rappelez-vous : vous n'ordonnez pas une tâche isolée. Vous exprimez une vision (ex : "Développer notre cocon sémantique sur la gamme VTT Électriques 2026"), et le cerveau construira la stratégie complète.
              </p>

              {/* Sample Quick Prompts */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-left w-full pt-2">
                {[
                  'Développer une nouvelle catégorie SEO de VTT Électriques 2026.',
                  'Optimiser les fiches produits WooCommerce sans balises Rank Math.',
                  'Auditer la santé technique complète du site WordPress.',
                  'Préparer un cocon sémantique sur la maintenance hivernale.',
                ].map((promptText, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setInputGoal(promptText);
                    }}
                    className="p-3 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl text-xs text-slate-300 hover:text-white transition-all text-left cursor-pointer hover:bg-slate-800/60"
                  >
                    « {promptText} »
                  </button>
                ))}
              </div>
            </div>
          ) : (
            currentConv.messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 max-w-3xl ${
                  msg.sender === 'user' ? 'ml-auto flex-row-reverse' : 'mr-auto'
                }`}
              >
                {/* Avatar */}
                <div
                  className={`w-8 h-8 rounded-lg shrink-0 flex items-center justify-center font-bold text-xs ${
                    msg.sender === 'user'
                      ? 'bg-blue-600 text-white'
                      : 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/30'
                  }`}
                >
                  {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>

                {/* Content Bubble */}
                <div className="space-y-3 flex-1 min-w-0">
                  <div
                    className={`relative group p-4 rounded-2xl text-xs leading-relaxed ${
                      msg.sender === 'user'
                        ? 'bg-blue-600 text-white shadow-md'
                        : 'bg-slate-900 border border-slate-800 text-slate-200 shadow-sm'
                    }`}
                  >
                    <button
                      onClick={() => handleCopyMessage(msg.id, msg.text)}
                      title="Copier ce message"
                      className={`absolute top-2.5 right-2.5 p-1.5 rounded-lg text-xs opacity-70 hover:opacity-100 transition-all cursor-pointer ${
                        msg.sender === 'user'
                          ? 'bg-blue-700/80 hover:bg-blue-700 text-blue-100'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                      }`}
                    >
                      {copiedMsgId === msg.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>

                    <div className="whitespace-pre-wrap pr-6">{msg.text}</div>

                    {/* Strategy Breakdown Card if Assistant produced Strategy */}
                    {msg.strategy && (
                      <div className="mt-4 pt-4 border-t border-slate-800 bg-slate-950 p-4 rounded-xl space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-mono uppercase font-semibold text-cyan-400 flex items-center space-x-1.5">
                            <Sparkles className="w-3.5 h-3.5" />
                            <span>Plan Stratégique DigiWare Découpé</span>
                          </span>
                          <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                            {msg.strategy.steps.length} étapes
                          </span>
                        </div>

                        <p className="text-xs text-slate-300 font-medium">{msg.strategy.summary}</p>

                        {/* Steps List */}
                        <div className="space-y-2 pt-1">
                          {msg.strategy.steps.map((step, idx) => (
                            <div
                              key={step.id || idx}
                              className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex items-start justify-between gap-3"
                            >
                              <div className="space-y-1">
                                <div className="flex items-center space-x-2">
                                  <span className="w-5 h-5 rounded bg-blue-500/20 text-blue-400 font-mono text-[10px] flex items-center justify-center font-bold">
                                    {idx + 1}
                                  </span>
                                  <h4 className="text-xs font-semibold text-white">{step.title}</h4>
                                </div>
                                <p className="text-[11px] text-slate-400">{step.description}</p>
                              </div>

                              <div className="flex items-center space-x-2 shrink-0">
                                <span className="uppercase text-[10px] font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded">
                                  {step.engine}
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>

                        {/* Send to Queue Action */}
                        <div className="pt-2 flex justify-end">
                          <button
                            onClick={() => handleSendStrategyToQueue(msg.strategy)}
                            className="flex items-center space-x-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-all shadow-md cursor-pointer"
                          >
                            <Layers className="w-3.5 h-3.5" />
                            <span>Transmettre au Queue Manager</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Suggested Quick Actions */}
                  {msg.suggestedActions && msg.suggestedActions.length > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {msg.suggestedActions.map((actionText, idx) => (
                        <button
                          key={idx}
                          onClick={() => setInputGoal(actionText)}
                          className="text-[11px] bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                        >
                          → {actionText}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))
          )}

          {isAiThinking && (
            <div className="flex items-center space-x-3 text-xs text-indigo-400 bg-slate-900 border border-slate-800 p-3 rounded-2xl max-w-sm">
              <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />
              <span>Le cerveau central élabore la stratégie...</span>
            </div>
          )}
        </div>

        {/* Natural Language Goal Input Form */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/80 shrink-0 space-y-2">
          {speechError && (
            <div className="bg-red-950/60 border border-red-500/30 text-red-300 text-[11px] p-2 rounded-lg font-mono flex items-center justify-between">
              <span>{speechError}</span>
              <button onClick={() => setSpeechError(null)} className="text-red-400 font-bold ml-2">✕</button>
            </div>
          )}

          <form onSubmit={handleSend} className="space-y-2">
            <div className="relative">
              <textarea
                value={inputGoal}
                onChange={(e) => setInputGoal(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                placeholder="Exprimez votre objectif global ou dictez-le à la voix (ex: 'Créer une campagne de contenu SEO avec fiches WooCommerce')..."
                rows={2}
                className="w-full bg-slate-950 border border-slate-800 focus:border-blue-500 text-xs text-slate-200 placeholder-slate-500 rounded-xl p-3 pr-24 focus:outline-none resize-none"
              />
              <div className="absolute right-3 bottom-3 flex items-center space-x-1.5">
                <button
                  type="button"
                  onClick={toggleVoiceRecognition}
                  title={isListening ? "Arrêter l'écoute vocale" : "Saisie vocale (Microphone)"}
                  className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all cursor-pointer ${
                    isListening
                      ? 'bg-red-600 animate-pulse text-white shadow-lg shadow-red-600/40'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                  }`}
                >
                  {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4 text-cyan-400" />}
                </button>
                <button
                  type="submit"
                  disabled={!inputGoal.trim() || isAiThinking}
                  className="w-8 h-8 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white flex items-center justify-center transition-colors cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
              <span className="flex items-center space-x-2">
                <span>Appuyez sur Entrée pour transmettre</span>
                {isListening && <span className="text-red-400 animate-pulse font-bold">• Écoute vocale active...</span>}
              </span>
              <span>Gemini 3.6 Flash Connecté</span>
            </div>
          </form>
        </div>
      </div>

      {/* New Project Modal */}
      {showNewProjModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <Folder className="w-5 h-5 text-blue-400" />
                <span>Nouveau Dossier Projet</span>
              </h3>
              <button
                onClick={() => setShowNewProjModal(false)}
                className="text-slate-400 hover:text-white text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateProjectSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Nom du Projet</label>
                <input
                  type="text"
                  value={newProjName}
                  onChange={(e) => setNewProjName(e.target.value)}
                  placeholder="ex: Lancement Vélos Cargo 2026"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-blue-500 text-xs text-white p-2.5 rounded-lg focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Description</label>
                <textarea
                  value={newProjDesc}
                  onChange={(e) => setNewProjDesc(e.target.value)}
                  placeholder="Objectif métier, périmètre et échéance..."
                  rows={3}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-blue-500 text-xs text-white p-2.5 rounded-lg focus:outline-none resize-none"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowNewProjModal(false)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs font-medium cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold cursor-pointer"
                >
                  Créer le Projet
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

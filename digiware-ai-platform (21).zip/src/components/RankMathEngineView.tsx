import React, { useState } from 'react';
import { usePlatform } from '../context/PlatformContext';
import {
  Search,
  Globe,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  FileCode,
  Share2,
} from 'lucide-react';

export const RankMathEngineView: React.FC = () => {
  const { wpPosts, wooProducts, addTasksToQueue, setActiveTab } = usePlatform();

  const [searchTarget, setSearchTarget] = useState<'posts' | 'products'>('posts');
  const [selectedItemId, setSelectedItemId] = useState<string>(wpPosts[0]?.id || '');
  const [previewMode, setPreviewMode] = useState<'desktop' | 'mobile'>('desktop');

  const currentItem =
    searchTarget === 'posts'
      ? wpPosts.find((p) => p.id === selectedItemId) || wpPosts[0]
      : wooProducts.find((p) => p.id === selectedItemId) || wooProducts[0];

  const focusKeyword = currentItem
    ? searchTarget === 'posts'
      ? (currentItem as any).focusKeyword
      : (currentItem as any).sku
    : '';

  const metaTitle = currentItem
    ? searchTarget === 'posts'
      ? (currentItem as any).metaTitle
      : (currentItem as any).seoTitle
    : '';

  const metaDescription = currentItem
    ? searchTarget === 'posts'
      ? (currentItem as any).metaDescription
      : (currentItem as any).seoDesc
    : '';

  const handleRunRankMathOptimization = () => {
    if (!currentItem) return;

    addTasksToQueue([
      {
        title: `Optimisation Rank Math Snippet & Schema : ${
          searchTarget === 'posts' ? (currentItem as any).title : (currentItem as any).name
        }`,
        engine: 'rankmath',
        status: 'pending',
        priority: 'high',
        payload: { itemId: currentItem.id, type: searchTarget },
      },
    ]);

    setActiveTab('queue');
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto text-slate-200">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="bg-purple-500/10 text-purple-400 border border-purple-500/20 text-xs font-mono px-2.5 py-0.5 rounded-full font-semibold">
              Balisage & Snippets Google
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Rank Math SEO Integration
            </span>
          </div>
          <h1 className="text-2xl font-bold text-white flex items-center space-x-2">
            <Search className="w-6 h-6 text-purple-400" />
            <span>Rank Math SEO Engine</span>
          </h1>
          <p className="text-xs text-slate-400 max-w-2xl">
            Simulez la présence de vos articles et produits dans les résultats de recherche Google. Calculez les densités de mots-clés et générez le balisage Schema FAQ.
          </p>
        </div>

        <button
          onClick={handleRunRankMathOptimization}
          className="flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold px-4 py-2.5 rounded-xl shadow-lg transition-all text-xs cursor-pointer shrink-0"
        >
          <Sparkles className="w-4 h-4" />
          <span>Optimiser via Rank Math IA</span>
        </button>
      </div>

      {/* Target Item Picker */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => {
              setSearchTarget('posts');
              setSelectedItemId(wpPosts[0]?.id || '');
            }}
            className={`px-3 py-1.5 rounded-lg font-medium cursor-pointer transition-colors ${
              searchTarget === 'posts'
                ? 'bg-purple-600 text-white font-semibold'
                : 'bg-slate-950 text-slate-400 hover:text-white'
            }`}
          >
            Articles Blog ({wpPosts.length})
          </button>
          <button
            onClick={() => {
              setSearchTarget('products');
              setSelectedItemId(wooProducts[0]?.id || '');
            }}
            className={`px-3 py-1.5 rounded-lg font-medium cursor-pointer transition-colors ${
              searchTarget === 'products'
                ? 'bg-purple-600 text-white font-semibold'
                : 'bg-slate-950 text-slate-400 hover:text-white'
            }`}
          >
            Produits WooCommerce ({wooProducts.length})
          </button>
        </div>

        <select
          value={selectedItemId}
          onChange={(e) => setSelectedItemId(e.target.value)}
          className="bg-slate-950 border border-slate-800 text-slate-200 rounded-lg px-3 py-1.5 focus:outline-none w-full sm:w-auto"
        >
          {searchTarget === 'posts'
            ? wpPosts.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.title}
                </option>
              ))
            : wooProducts.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
        </select>
      </div>

      {/* Google SERP Simulator */}
      {currentItem && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* SERP Snippet Preview */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-semibold text-white flex items-center space-x-2">
                <Globe className="w-4 h-4 text-purple-400" />
                <span>Simulateur Snippet Google SERP</span>
              </h3>
              <div className="flex items-center space-x-1 text-[11px] font-mono">
                <button
                  onClick={() => setPreviewMode('desktop')}
                  className={`px-2 py-0.5 rounded cursor-pointer ${
                    previewMode === 'desktop' ? 'bg-purple-600 text-white' : 'text-slate-400'
                  }`}
                >
                  Desktop
                </button>
                <button
                  onClick={() => setPreviewMode('mobile')}
                  className={`px-2 py-0.5 rounded cursor-pointer ${
                    previewMode === 'mobile' ? 'bg-purple-600 text-white' : 'text-slate-400'
                  }`}
                >
                  Mobile
                </button>
              </div>
            </div>

            {/* Google SERP Card */}
            <div
              className={`bg-white text-slate-900 p-4 rounded-xl space-y-1 font-sans shadow-md ${
                previewMode === 'mobile' ? 'max-w-sm mx-auto border-2 border-slate-300' : 'w-full'
              }`}
            >
              <div className="flex items-center space-x-2 text-[11px] text-slate-600">
                <span className="w-4 h-4 rounded-full bg-slate-200 flex items-center justify-center font-bold text-[9px]">
                  G
                </span>
                <span className="truncate">
                  https://mon-site-wordpress.com › {searchTarget === 'posts' ? 'blog' : 'produit'} ›{' '}
                  {(currentItem as any).slug || (currentItem as any).sku}
                </span>
              </div>
              <h2 className="text-blue-800 font-medium text-base hover:underline cursor-pointer leading-tight truncate">
                {metaTitle || (currentItem as any).title || (currentItem as any).name}
              </h2>
              <p className="text-slate-600 text-xs line-clamp-2 leading-relaxed">
                {metaDescription || 'Aucune description configurée.'}
              </p>
            </div>

            <div className="text-[11px] text-slate-400 font-mono space-y-1 pt-2">
              <div className="flex justify-between">
                <span>Longueur Title :</span>
                <span className="text-emerald-400">{metaTitle?.length || 0} / 60 caractères (Optimal)</span>
              </div>
              <div className="flex justify-between">
                <span>Longueur Description :</span>
                <span className="text-emerald-400">{metaDescription?.length || 0} / 160 caractères (Optimal)</span>
              </div>
            </div>
          </div>

          {/* Rank Math SEO Diagnostic Checks */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-semibold text-white flex items-center space-x-2">
                <TrendingUp className="w-4 h-4 text-purple-400" />
                <span>Checklist de Conformité Rank Math</span>
              </h3>
              <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                Score: 88/100
              </span>
            </div>

            <div className="space-y-2 text-xs font-mono">
              {[
                { label: 'Mot-clé cible présent dans le titre H1', ok: true },
                { label: 'Mot-clé cible présent dans la méta description', ok: true },
                { label: 'Présence d\'au moins un sous-titre H2 avec mot-clé secondaire', ok: true },
                { label: 'Densité de mot-clé mesurée à 1.8% (Cible : 1.2% - 2.5%)', ok: true },
                { label: 'Balisage FAQ Schema JSON-LD injecté dans le header', ok: true },
                { label: 'Liaison canonique auto-référencée sécurisée', ok: true },
              ].map((check, idx) => (
                <div
                  key={idx}
                  className="p-2.5 bg-slate-950 rounded-lg border border-slate-850 flex items-center justify-between"
                >
                  <span className="text-slate-300">{check.label}</span>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

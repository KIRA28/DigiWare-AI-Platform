import React from 'react';
import { PlatformProvider, usePlatform } from './context/PlatformContext';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { AIWorkspaceView } from './components/AIWorkspaceView';
import { QueueManagerView } from './components/QueueManagerView';
import { PolicyEngineView } from './components/PolicyEngineView';
import { SchedulerView } from './components/SchedulerView';
import { WordPressEngineView } from './components/WordPressEngineView';
import { WooCommerceEngineView } from './components/WooCommerceEngineView';
import { RankMathEngineView } from './components/RankMathEngineView';
import { SiteAuditView } from './components/SiteAuditView';
import { WPSettingsView } from './components/WPSettingsView';
import { TaskResultsView } from './components/TaskResultsView';

const MainContent: React.FC = () => {
  const { activeTab } = usePlatform();

  return (
    <div className="flex-1 overflow-y-auto bg-slate-950">
      {activeTab === 'dashboard' && <DashboardView />}
      {activeTab === 'workspace' && <AIWorkspaceView />}
      {activeTab === 'queue' && <QueueManagerView />}
      {activeTab === 'results' && <TaskResultsView />}
      {activeTab === 'policies' && <PolicyEngineView />}
      {activeTab === 'scheduler' && <SchedulerView />}
      {activeTab === 'wordpress' && <WordPressEngineView />}
      {activeTab === 'woocommerce' && <WooCommerceEngineView />}
      {activeTab === 'rankmath' && <RankMathEngineView />}
      {activeTab === 'audit' && <SiteAuditView />}
      {activeTab === 'settings' && <WPSettingsView />}
    </div>
  );
};

export default function App() {
  return (
    <PlatformProvider>
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans antialiased selection:bg-blue-600 selection:text-white">
        <Header />
        <div className="flex-1 flex overflow-hidden">
          <Sidebar />
          <MainContent />
        </div>
      </div>
    </PlatformProvider>
  );
}
